import { useState } from "react";
import {
  Calendar,
  Clock,
  Plus,
  Search,
  Filter,
  Download,
  Upload,
  Users,
  BookOpen,
  MapPin,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  MoreVertical,
  User,
  Wifi,
  Camera,
  Bluetooth,
  QrCode,
  Activity,
  Zap, // Added missing import
} from "lucide-react";

const SchedulePage = () => {
  const [currentView, setCurrentView] = useState("week");
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedTimeSlot, setSelectedTimeSlot] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState("");

  // Mock schedule data
  const scheduleData = {
    monday: [
      {
        id: 1,
        subject: "Mathematics",
        class: "10-A",
        teacher: "Dr. Sarah Johnson",
        room: "Room 101",
        time: "09:00-10:00",
        status: "scheduled",
        attendanceMethod: "face",
        studentsCount: 32,
        type: "regular",
      },
      {
        id: 2,
        subject: "Physics",
        class: "11-B",
        teacher: "Prof. Michael Chen",
        room: "Lab 201",
        time: "10:00-11:00",
        status: "ongoing",
        attendanceMethod: "ble",
        studentsCount: 28,
        type: "regular",
      },
      {
        id: 3,
        subject: "Smart Activity",
        class: "12-A",
        teacher: "AI Assistant",
        room: "Study Hall",
        time: "11:00-12:00",
        status: "scheduled",
        attendanceMethod: "wifi",
        studentsCount: 15,
        type: "smart-activity",
      },
    ],
    tuesday: [
      {
        id: 4,
        subject: "Chemistry",
        class: "10-B",
        teacher: "Ms. Emily Davis",
        room: "Lab 102",
        time: "09:00-10:00",
        status: "cancelled",
        attendanceMethod: "qr",
        studentsCount: 30,
        type: "regular",
        reason: "Teacher absent - substitute needed",
      },
    ],
    wednesday: [],
    thursday: [],
    friday: [],
  };

  const timeSlots = [
    "08:00-09:00",
    "09:00-10:00",
    "10:00-11:00",
    "11:00-12:00",
    "12:00-13:00",
    "13:00-14:00",
    "14:00-15:00",
    "15:00-16:00",
    "16:00-17:00",
  ];

  const classrooms = [
    "Room 101",
    "Room 102",
    "Room 103",
    "Lab 201",
    "Lab 202",
    "Lab 203",
    "Study Hall",
    "Library",
    "Auditorium",
  ];

  const teachers = [
    {
      id: 1,
      name: "Dr. Sarah Johnson",
      subject: "Mathematics",
      available: true,
    },
    { id: 2, name: "Prof. Michael Chen", subject: "Physics", available: false },
    { id: 3, name: "Ms. Emily Davis", subject: "Chemistry", available: true },
    { id: 4, name: "Mr. James Wilson", subject: "Biology", available: true },
  ];

  const classes = [
    "9-A",
    "9-B",
    "10-A",
    "10-B",
    "11-A",
    "11-B",
    "12-A",
    "12-B",
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case "scheduled":
        return "bg-blue-400/20 text-blue-200 border-blue-400/30";
      case "ongoing":
        return "bg-emerald-400/20 text-emerald-200 border-emerald-400/30";
      case "completed":
        return "bg-white/20 text-white/70 border-white/30";
      case "cancelled":
        return "bg-red-400/20 text-red-200 border-red-400/30";
      default:
        return "bg-white/20 text-white/70 border-white/30";
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case "regular":
        return "bg-blue-400/10 backdrop-blur-sm border-l-4 border-blue-400";
      case "smart-activity":
        return "bg-purple-400/10 backdrop-blur-sm border-l-4 border-purple-400";
      case "substitute":
        return "bg-orange-400/10 backdrop-blur-sm border-l-4 border-orange-400";
      default:
        return "bg-white/5 backdrop-blur-sm border-l-4 border-white/20";
    }
  };

  const getMethodIcon = (method) => {
    switch (method) {
      case "face":
        return <Camera className="w-3 h-3" />;
      case "ble":
        return <Bluetooth className="w-3 h-3" />;
      case "wifi":
        return <Wifi className="w-3 h-3" />;
      case "qr":
        return <QrCode className="w-3 h-3" />;
      default:
        return null;
    }
  };

  const formatDate = (date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const getWeekDates = (date) => {
    const week = [];
    const startOfWeek = new Date(date);
    const day = startOfWeek.getDay();
    const diff = startOfWeek.getDate() - day + (day === 0 ? -6 : 1);
    startOfWeek.setDate(diff);

    for (let i = 0; i < 5; i++) {
      const weekDay = new Date(startOfWeek);
      weekDay.setDate(startOfWeek.getDate() + i);
      week.push(weekDay);
    }
    return week;
  };

  // Date navigation functions
  const goToPreviousWeek = () => {
    const newDate = new Date(currentDate);
    newDate.setDate(currentDate.getDate() - 7);
    setCurrentDate(newDate);
  };

  const goToNextWeek = () => {
    const newDate = new Date(currentDate);
    newDate.setDate(currentDate.getDate() + 7);
    setCurrentDate(newDate);
  };

  const weekDays = ["monday", "tuesday", "wednesday", "thursday", "friday"];
  const weekDates = getWeekDates(currentDate);

  const ClassCard = ({ classData }) => (
    <div
      className={`p-3 rounded-xl border border-white/20 ${getTypeColor(
        classData.type
      )} hover:shadow-xl hover:scale-105 transition-all duration-300 cursor-pointer group`}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <h4 className="font-semibold text-white text-sm">
              {classData.subject}
            </h4>
            <span
              className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(
                classData.status
              )}`}
            >
              {classData.status}
            </span>
          </div>
          <div className="space-y-1">
            <div className="flex items-center space-x-2 text-xs text-white/70">
              <Users className="w-3 h-3" />
              <span>
                {classData.class} • {classData.studentsCount} students
              </span>
            </div>
            <div className="flex items-center space-x-2 text-xs text-white/70">
              <User className="w-3 h-3" />
              <span>{classData.teacher}</span>
            </div>
            <div className="flex items-center space-x-2 text-xs text-white/70">
              <MapPin className="w-3 h-3" />
              <span>{classData.room}</span>
            </div>
            <div className="flex items-center space-x-2 text-xs text-white/70">
              {getMethodIcon(classData.attendanceMethod)}
              <span className="capitalize">
                {classData.attendanceMethod} tracking
              </span>
            </div>
          </div>
          {classData.reason && (
            <div className="mt-2 flex items-center space-x-1 text-xs text-red-300">
              <AlertTriangle className="w-3 h-3" />
              <span>{classData.reason}</span>
            </div>
          )}
        </div>
        <div className="opacity-0 group-hover:opacity-100 transition-opacity">
          <button className="p-1 hover:bg-white/10 rounded-lg transition-colors">
            <MoreVertical className="w-4 h-4 text-white/60" />
          </button>
        </div>
      </div>
    </div>
  );

  const AddClassModal = () => (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900/95 backdrop-blur-xl border border-white/20 rounded-3xl p-8 w-full max-w-2xl mx-4 shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold text-white">Schedule New Class</h3>
          <button
            onClick={() => setShowModal(false)}
            className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-200"
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-white/90 mb-2">
                Subject
              </label>
              <input
                type="text"
                className="w-full px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white placeholder-white/50 focus:ring-2 focus:ring-emerald-400 focus:border-transparent transition-all"
                placeholder="Enter subject name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-white/90 mb-2">
                Class
              </label>
              <select className="w-full px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white focus:ring-2 focus:ring-emerald-400 focus:border-transparent transition-all">
                <option value="" className="bg-slate-800 text-white">
                  Select class
                </option>
                {classes.map((cls) => (
                  <option
                    key={cls}
                    value={cls}
                    className="bg-slate-800 text-white"
                  >
                    {cls}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-white/90 mb-2">
                Teacher
              </label>
              <select className="w-full px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white focus:ring-2 focus:ring-emerald-400 focus:border-transparent transition-all">
                <option value="" className="bg-slate-800 text-white">
                  Select teacher
                </option>
                {teachers
                  .filter((t) => t.available)
                  .map((teacher) => (
                    <option
                      key={teacher.id}
                      value={teacher.name}
                      className="bg-slate-800 text-white"
                    >
                      {teacher.name}
                    </option>
                  ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-white/90 mb-2">
                Room
              </label>
              <select className="w-full px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white focus:ring-2 focus:ring-emerald-400 focus:border-transparent transition-all">
                <option value="" className="bg-slate-800 text-white">
                  Select room
                </option>
                {classrooms.map((room) => (
                  <option
                    key={room}
                    value={room}
                    className="bg-slate-800 text-white"
                  >
                    {room}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-white/90 mb-2">
                Date
              </label>
              <input
                type="date"
                className="w-full px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white focus:ring-2 focus:ring-emerald-400 focus:border-transparent transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-white/90 mb-2">
                Time Slot
              </label>
              <select className="w-full px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white focus:ring-2 focus:ring-emerald-400 focus:border-transparent transition-all">
                <option value="" className="bg-slate-800 text-white">
                  Select time
                </option>
                {timeSlots.map((slot) => (
                  <option
                    key={slot}
                    value={slot}
                    className="bg-slate-800 text-white"
                  >
                    {slot}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-white/90 mb-2">
                Attendance Method
              </label>
              <select className="w-full px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white focus:ring-2 focus:ring-emerald-400 focus:border-transparent transition-all">
                <option value="face" className="bg-slate-800 text-white">
                  Face Recognition
                </option>
                <option value="ble" className="bg-slate-800 text-white">
                  Bluetooth (BLE)
                </option>
                <option value="wifi" className="bg-slate-800 text-white">
                  Wi-Fi Wearables
                </option>
                <option value="qr" className="bg-slate-800 text-white">
                  QR Code
                </option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-white/90 mb-2">
                Class Type
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button className="flex items-center justify-center space-x-2 px-4 py-3 bg-blue-500/20 border border-blue-400/30 rounded-2xl text-blue-200 hover:bg-blue-500/30 transition-all">
                  <BookOpen className="w-4 h-4" />
                  <span>Regular</span>
                </button>
                <button className="flex items-center justify-center space-x-2 px-4 py-3 bg-purple-500/20 border border-purple-400/30 rounded-2xl text-purple-200 hover:bg-purple-500/30 transition-all">
                  <Zap className="w-4 h-4" />
                  <span>Smart Activity</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="flex space-x-4 pt-8">
          <button
            type="button"
            onClick={() => setShowModal(false)}
            className="flex-1 px-6 py-3 bg-white/10 backdrop-blur-sm border border-white/20 text-white rounded-2xl hover:bg-white/20 transition-all duration-300"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="flex-1 px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-2xl hover:from-emerald-400 hover:to-teal-400 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Schedule Class
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative overflow-hidden rounded-xl border border-white/20">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-cyan-400/10 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Grid Pattern Overlay */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,255,255,0.3) 1px, transparent 0)`,
          backgroundSize: "24px 24px",
        }}
      ></div>

      <div className="relative z-10">
        {/* Header */}
        <div className="bg-white/5 backdrop-blur-xl border-b border-white/20 sticky top-0">
          <div className="px-6 py-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-white via-blue-100 to-cyan-200 bg-clip-text text-transparent">
                  Schedule Management
                </h1>
                <p className="text-white/60 mt-2 font-medium">
                  {formatDate(currentDate)}
                </p>
              </div>

              <div className="flex items-center space-x-6">
                <div className="flex items-center bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-1">
                  <button
                    onClick={() => setCurrentView("day")}
                    className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                      currentView === "day"
                        ? "bg-white/20 text-white shadow-lg"
                        : "text-white/70 hover:text-white hover:bg-white/10"
                    }`}
                  >
                    Day
                  </button>
                  <button
                    onClick={() => setCurrentView("week")}
                    className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                      currentView === "week"
                        ? "bg-white/20 text-white shadow-lg"
                        : "text-white/70 hover:text-white hover:bg-white/10"
                    }`}
                  >
                    Week
                  </button>
                  <button
                    onClick={() => setCurrentView("month")}
                    className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                      currentView === "month"
                        ? "bg-white/20 text-white shadow-lg"
                        : "text-white/70 hover:text-white hover:bg-white/10"
                    }`}
                  >
                    Month
                  </button>
                </div>

                <div className="flex items-center space-x-3">
                  <button
                    onClick={goToPreviousWeek}
                    className="p-3 text-white/70 hover:text-white hover:bg-white/10 rounded-2xl transition-all duration-200"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button
                    onClick={goToNextWeek}
                    className="p-3 text-white/70 hover:text-white hover:bg-white/10 rounded-2xl transition-all duration-200"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>

                <button
                  onClick={() => setShowModal(true)}
                  className="flex items-center space-x-3 px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-2xl hover:from-emerald-400 hover:to-teal-400 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  <Plus className="w-5 h-5" />
                  <span className="font-medium">Add Class</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="px-6 py-6 bg-white/5 backdrop-blur-sm border-b border-white/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/50 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search classes, teachers, rooms..."
                  className="pl-12 pr-6 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white placeholder-white/50 focus:ring-2 focus:ring-emerald-400 focus:border-transparent w-80 transition-all"
                />
              </div>
              <button className="flex items-center space-x-2 px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white/80 hover:text-white hover:bg-white/20 transition-all duration-300">
                <Filter className="w-4 h-4" />
                <span>Filter</span>
              </button>
            </div>

            <div className="flex items-center space-x-3">
              <button className="flex items-center space-x-2 px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white/80 hover:text-white hover:bg-white/20 transition-all duration-300">
                <Upload className="w-4 h-4" />
                <span>Import</span>
              </button>
              <button className="flex items-center space-x-2 px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white/80 hover:text-white hover:bg-white/20 transition-all duration-300">
                <Download className="w-4 h-4" />
                <span>Export</span>
              </button>
              {/* <button className="flex items-center space-x-2 px-4 py-3 bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-blue-400/30 rounded-2xl text-blue-200 hover:from-blue-500/30 hover:to-purple-500/30 transition-all duration-300">
                <RefreshCw className="w-4 h-4" />
                <span>Auto-Reschedule</span>
              </button> */}
            </div>
          </div>
        </div>

        {/* Schedule Grid */}
        <div className="p-6">
          {currentView === "week" && (
            <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-3xl overflow-hidden shadow-2xl">
              <div className="grid grid-cols-6 divide-x divide-white/10">
                {/* Time Column */}
                <div className="bg-white/5 backdrop-blur-sm p-6">
                  <div className="font-bold text-white mb-6 flex items-center">
                    <Clock className="w-5 h-5 mr-2" />
                    Time
                  </div>
                  <div className="space-y-4">
                    {timeSlots.map((slot) => (
                      <div
                        key={slot}
                        className="text-sm text-white/70 py-8 border-b border-white/10 last:border-b-0 font-medium"
                      >
                        {slot}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Days Columns */}
                {weekDays.map((day, index) => (
                  <div key={day} className="p-6">
                    <div className="font-bold text-white mb-6 capitalize">
                      {day}{" "}
                      {weekDates[index] && (
                        <span className="text-sm font-normal text-white/60 ml-2">
                          ({weekDates[index].getDate()})
                        </span>
                      )}
                    </div>
                    <div className="space-y-4">
                      {timeSlots.map((slot) => (
                        <div
                          key={`${day}-${slot}`}
                          className="min-h-[96px] border-b border-white/5 last:border-b-0 py-2"
                        >
                          {scheduleData[day] &&
                            scheduleData[day]
                              .filter((cls) => cls.time === slot)
                              .map((cls) => (
                                <ClassCard key={cls.id} classData={cls} />
                              ))}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8">
            <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
              <div className="flex items-center space-x-4">
                <div className="bg-gradient-to-r from-blue-500 to-cyan-500 p-3 rounded-2xl shadow-lg">
                  <Calendar className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-3xl font-bold text-white">28</p>
                  <p className="text-white/60 font-medium">
                    Total Classes Today
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
              <div className="flex items-center space-x-4">
                <div className="bg-gradient-to-r from-emerald-500 to-teal-500 p-3 rounded-2xl shadow-lg">
                  <CheckCircle2 className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-3xl font-bold text-white">25</p>
                  <p className="text-white/60 font-medium">Classes Completed</p>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
              <div className="flex items-center space-x-4">
                <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-3 rounded-2xl shadow-lg">
                  <Activity className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-3xl font-bold text-white">12</p>
                  <p className="text-white/60 font-medium">Smart Activities</p>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
              <div className="flex items-center space-x-4">
                <div className="bg-gradient-to-r from-red-500 to-orange-500 p-3 rounded-2xl shadow-lg">
                  <AlertTriangle className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-3xl font-bold text-white">2</p>
                  <p className="text-white/60 font-medium">Conflicts/Issues</p>
                </div>
              </div>
            </div>
          </div>

          {/* Upcoming Smart Activities - Fixed styling to match dark theme */}
          <div className="mt-8 bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">
                Upcoming Smart Activities
              </h3>
              <button className="text-emerald-300 hover:text-emerald-200 text-sm font-medium transition-colors">
                View All
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="border border-purple-400/30 rounded-xl p-4 bg-purple-500/10 backdrop-blur-sm">
                <div className="flex items-center space-x-2 mb-2">
                  <Activity className="w-4 h-4 text-purple-300" />
                  <span className="font-medium text-purple-200">
                    Career Guidance Quiz
                  </span>
                </div>
                <p className="text-sm text-purple-300/80 mb-2">
                  Class 12-A • Study Hall
                </p>
                <p className="text-xs text-purple-300/60">
                  11:00 AM - 12:00 PM
                </p>
                <p className="text-xs text-purple-300/60">
                  15 students enrolled
                </p>
              </div>

              <div className="border border-purple-400/30 rounded-xl p-4 bg-purple-500/10 backdrop-blur-sm">
                <div className="flex items-center space-x-2 mb-2">
                  <BookOpen className="w-4 h-4 text-purple-300" />
                  <span className="font-medium text-purple-200">
                    Micro-lesson: Physics
                  </span>
                </div>
                <p className="text-sm text-purple-300/80 mb-2">
                  Class 11-B • Library
                </p>
                <p className="text-xs text-purple-300/60">
                  02:00 PM - 02:30 PM
                </p>
                <p className="text-xs text-purple-300/60">
                  8 students enrolled
                </p>
              </div>

              <div className="border border-purple-400/30 rounded-xl p-4 bg-purple-500/10 backdrop-blur-sm">
                <div className="flex items-center space-x-2 mb-2">
                  <Users className="w-4 h-4 text-purple-300" />
                  <span className="font-medium text-purple-200">
                    Peer Study Group
                  </span>
                </div>
                <p className="text-sm text-purple-300/80 mb-2">
                  Mixed Classes • Room 103
                </p>
                <p className="text-xs text-purple-300/60">
                  03:00 PM - 04:00 PM
                </p>
                <p className="text-xs text-purple-300/60">
                  12 students enrolled
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal */}
        {showModal && <AddClassModal />}
      </div>
    </div>
  );
};

export default SchedulePage;
