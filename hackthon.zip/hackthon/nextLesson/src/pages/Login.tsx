import React, { useState } from "react";
import {
  Eye,
  EyeOff,
  BookOpen,
  Users,
  Calendar,
  BarChart3,
  Zap,
  Shield,
  Brain,
  ArrowRight,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function LoginPage() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [userType, setUserType] = useState("student");
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    rememberMe: false,
  });

  const handleInputChange = (e: { target: { name: any; value: any; type: any; checked: any; }; }) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = (e: { preventDefault: () => void; }) => {
    e.preventDefault();
    console.log("Login attempt:", { ...formData, userType });
    // Navigation logic would go here
    navigate(`/${userType}`);
  };

  const userTypes = [
    { id: "student", label: "Student", icon: BookOpen, gradient: "from-blue-500 to-cyan-400" },
    { id: "teacher", label: "Teacher", icon: Users, gradient: "from-emerald-500 to-teal-400" },
    { id: "admin", label: "Admin", icon: BarChart3, gradient: "from-purple-500 to-pink-400" },
  ];

  const features = [
    { icon: Zap, title: "AI-Powered", desc: "Smart automation" },
    { icon: Shield, title: "Secure", desc: "Data protection" },
    { icon: Brain, title: "Intelligent", desc: "Personalized learning" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-cyan-400/10 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Grid Pattern Overlay */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,255,255,0.3) 1px, transparent 0)`,
          backgroundSize: '24px 24px'
        }}
      ></div>

      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Left Side - Branding & Features */}
          <div className="text-white space-y-8 lg:pr-12">
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-2xl flex items-center justify-center shadow-2xl">
                    <Calendar className="w-8 h-8 text-white" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-6 h-6 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-full flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  </div>
                </div>
                <div>
                  <h1 className="text-4xl lg:text-5xl font-bold bg-gradient-to-r from-white via-blue-100 to-cyan-200 bg-clip-text text-transparent">
                    NextLesson
                  </h1>
                  <p className="text-blue-200/80 font-medium">Smart India Hackathon 2025</p>
                </div>
              </div>
              
              <div className="space-y-3">
                <h2 className="text-2xl lg:text-3xl font-semibold text-white/90">
                  Revolutionizing Education with
                  <span className="block bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                    Smart Technology
                  </span>
                </h2>
                <p className="text-blue-100/70 text-lg leading-relaxed">
                  Experience the future of classroom management with automated attendance tracking and intelligent curriculum recommendations.
                </p>
              </div>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-3 gap-4">
              {features.map((feature, index) => (
                <div key={index} className="group">
                  <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-4 hover:bg-white/10 transition-all duration-300 group-hover:scale-105">
                    <div className="w-10 h-10 bg-gradient-to-r from-blue-400/20 to-cyan-400/20 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                      <feature.icon className="w-5 h-5 text-cyan-300" />
                    </div>
                    <h3 className="font-semibold text-white/90 mb-1">{feature.title}</h3>
                    <p className="text-blue-200/60 text-sm">{feature.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="hidden lg:block">
              <div className="bg-gradient-to-r from-blue-500/10 to-cyan-400/10 backdrop-blur-sm border border-blue-400/20 rounded-2xl p-6">
                <div className="flex items-center space-x-3 mb-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-lg flex items-center justify-center">
                    <BookOpen className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-white/90 font-medium">NEP 2020 Aligned</span>
                </div>
                <p className="text-blue-200/70 text-sm">
                  Built to support India's National Education Policy with personalized, technology-enabled learning experiences.
                </p>
              </div>
            </div>
          </div>

          {/* Right Side - Login Form */}
          <div className="w-full max-w-md mx-auto">
            <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl shadow-2xl overflow-hidden">
              
              {/* User Type Selection */}
              <div className="p-8 pb-6">
                <h3 className="text-xl font-semibold text-white mb-6">Welcome Back</h3>
                <div className="space-y-3">
                  <p className="text-sm font-medium text-white/70">Select your role</p>
                  <div className="grid grid-cols-3 gap-3">
                    {userTypes.map(({ id, label, icon: Icon, gradient }) => (
                      <button
                        key={id}
                        onClick={() => setUserType(id)}
                        className={`relative p-4 rounded-2xl border transition-all duration-300 group ${
                          userType === id
                            ? "border-white/40 bg-white/15 shadow-lg scale-105"
                            : "border-white/10 bg-white/5 hover:bg-white/10 hover:border-white/20"
                        }`}
                      >
                        <div className={`w-8 h-8 bg-gradient-to-r ${gradient} rounded-xl flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform`}>
                          <Icon className="w-4 h-4 text-white" />
                        </div>
                        <p className="text-xs font-medium text-white/80">{label}</p>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Login Form */}
              <div className="px-8 pb-8">
                <div className="space-y-5">
                  {/* Email Field */}
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-white/80">
                      Email Address
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl focus:ring-2 focus:ring-cyan-400 focus:border-transparent transition-all duration-200 text-white placeholder-white/40 hover:bg-white/15"
                      placeholder="Enter your email"
                    />
                  </div>

                  {/* Password Field */}
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-white/80">
                      Password
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? "text" : "password"}
                        name="password"
                        value={formData.password}
                        onChange={handleInputChange}
                        required
                        className="w-full px-4 py-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl focus:ring-2 focus:ring-cyan-400 focus:border-transparent transition-all duration-200 text-white placeholder-white/40 pr-12 hover:bg-white/15"
                        placeholder="Enter your password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white/60 hover:text-white/80 transition-colors"
                      >
                        {showPassword ? (
                          <EyeOff className="w-5 h-5" />
                        ) : (
                          <Eye className="w-5 h-5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Remember Me & Forgot Password */}
                  <div className="flex items-center justify-between pt-2">
                    <label className="flex items-center group cursor-pointer">
                      <input
                        type="checkbox"
                        name="rememberMe"
                        checked={formData.rememberMe}
                        onChange={handleInputChange}
                        className="w-4 h-4 rounded border-white/20 bg-white/10 text-cyan-400 focus:ring-cyan-400 focus:ring-offset-0"
                      />
                      <span className="ml-3 text-sm text-white/70 group-hover:text-white/90 transition-colors">
                        Remember me
                      </span>
                    </label>
                    <button
                      type="button"
                      className="text-sm text-cyan-300 hover:text-cyan-200 font-medium transition-colors"
                    >
                      Forgot password?
                    </button>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    onClick={handleSubmit}
                    className="w-full mt-8 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-white font-semibold py-4 px-6 rounded-2xl transition-all duration-300 transform hover:scale-[1.02] hover:shadow-2xl focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-offset-2 focus:ring-offset-transparent group flex items-center justify-center space-x-2"
                  >
                    <span>Sign In as {userTypes.find((type) => type.id === userType)?.label}</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>

                {/* Footer */}
                <div className="mt-8 pt-6 border-t border-white/10 text-center">
                  <p className="text-sm text-white/60">
                    Don't have an account?{" "}
                    <button className="text-cyan-300 hover:text-cyan-200 font-medium transition-colors hover:underline">
                      Contact Administrator
                    </button>
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="mt-6 grid grid-cols-2 gap-4">
              <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-4 text-center hover:bg-white/10 transition-colors">
                <div className="text-2xl font-bold text-cyan-300 mb-1">50+</div>
                <div className="text-xs text-white/60">Hours Saved/Semester</div>
              </div>
              <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-4 text-center hover:bg-white/10 transition-colors">
                <div className="text-2xl font-bold text-emerald-300 mb-1">30%</div>
                <div className="text-xs text-white/60">Productivity Increase</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}