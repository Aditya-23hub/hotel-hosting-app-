import { useState } from "react";
import {
  Calendar,
  BookOpen,
  Bell,
  User,
  Clock,
  Award,
  Menu,
  GraduationCap,
  Settings,
  Activity,
} from "lucide-react";
import ScheduleTable from "../components/ScheduleTable";
import SDashboard from "../components/StudentDashboard";
import StudentAttendance from "../components/StudentAttendance";
import StudentGrades from "../components/StudentGrads";
import StudentAssignments from "../components/StudentAssignment";
import SettingsComponent from "../components/Setting";

// Main Component
export default function StudentPortal() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Student data
  const studentData = {
    name: "Alex Johnson",
    rollNumber: "2024CSE101",
    class: "Computer Science - B.Tech",
    semester: "5th Semester",
    attendance: 85.5,
    cgpa: 8.7,
  };

  // Navigation items
  const navigationItems = [
    {
      id: "dashboard",
      label: "Dashboard",
      icon: BookOpen,
      gradient: "from-blue-500 to-cyan-500",
    },
    {
      id: "schedule",
      label: "Class Schedule",
      icon: Calendar,
      gradient: "from-emerald-500 to-teal-500",
    },
    {
      id: "attendance",
      label: "Attendance",
      icon: Clock,
      gradient: "from-purple-500 to-pink-500",
    },
    {
      id: "grades",
      label: "Grades & Results",
      icon: Award,
      gradient: "from-orange-500 to-red-500",
    },
    {
      id: "assignments",
      label: "Assignments",
      icon: BookOpen,
      gradient: "from-indigo-500 to-purple-500",
    },
    {
      id: "settings",
      label: "Settings",
      icon: Settings,
      gradient: "from-gray-500 to-slate-500",
    },
  ];

  const weeklyData = [
    { week: "W1", attendance: 80 },
    { week: "W2", attendance: 85 },
    { week: "W3", attendance: 88 },
    { week: "W4", attendance: 92 },
  ];

  const subjectData = [
    { subject: "Math", attendance: 95 },
    { subject: "Physics", attendance: 88 },
    { subject: "Chemistry", attendance: 76 },
    { subject: "English", attendance: 90 },
    { subject: "History", attendance: 65 },
  ];

  const calendarData = [
    { date: "1", present: true },
    { date: "2", present: false },
    { date: "3", present: true },
    { date: "4", present: true },
    { date: "5", present: true },
    { date: "6", present: false },
    { date: "7", present: true },
    { date: "8", present: true },
    { date: "9", present: false },
  ];

  const gpa = 3.7;
  const resultStatus = "Pass";

  const subjects = [
    { subject: "Math", grade: "A", credits: 4 },
    { subject: "Physics", grade: "B+", credits: 3 },
    { subject: "Chemistry", grade: "A+", credits: 4 },
    { subject: "English", grade: "B", credits: 2 },
    { subject: "History", grade: "C", credits: 3 },
    { subject: "Biology", grade: "A", credits: 3 },
  ];

  const assignments = [
    {
      title: "Math Homework - Algebra",
      dueDate: "2025-09-30",
      status: "Pending",
      progress: 40,
    },
    {
      title: "Physics Lab Report",
      dueDate: "2025-09-25",
      status: "Submitted",
      progress: 100,
    },
    {
      title: "Chemistry Assignment - Organic",
      dueDate: "2025-09-28",
      status: "Late",
      progress: 70,
    },
    {
      title: "History Essay",
      dueDate: "2025-10-01",
      status: "Pending",
      progress: 20,
    },
  ];

  // Header Component
  const Header = ({ onMenuClick, studentName, rollNumber }) => (
    <header className="relative z-10 bg-white/5 backdrop-blur-xl border-b border-white/20 sticky top-0">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          {/* Left Side */}
          <div className="flex items-center space-x-4">
            <button
              onClick={onMenuClick}
              className="lg:hidden p-3 rounded-2xl text-white/70 hover:text-white hover:bg-white/10 transition-all duration-200"
            >
              <Menu className="w-6 h-6" />
            </button>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-400 rounded-2xl flex items-center justify-center shadow-2xl">
                  <GraduationCap className="w-6 h-6 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-emerald-400 to-cyan-400 rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                </div>
              </div>
              <div>
                <span className="text-2xl font-bold bg-gradient-to-r from-white via-blue-100 to-cyan-200 bg-clip-text text-transparent">
                  EduPortal
                </span>
                <p className="text-blue-200/80 text-sm font-medium hidden sm:block">
                  Student Dashboard
                </p>
              </div>
            </div>
          </div>

          {/* Right Side */}
          <div className="flex items-center space-x-4">
            {/* Status */}
            <div className="hidden sm:flex items-center space-x-3 px-4 py-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl">
              <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse shadow-lg shadow-emerald-400/50"></div>
              <span className="text-sm text-white/90 font-medium">Online</span>
            </div>

            {/* Notifications */}
            <button className="relative p-3 text-white/70 hover:text-white hover:bg-white/10 rounded-2xl transition-all duration-200">
              <Bell className="w-6 h-6" />
              <span className="absolute top-1 right-1 w-3 h-3 bg-gradient-to-r from-red-500 to-pink-400 rounded-full animate-pulse shadow-lg"></span>
            </button>

            {/* Profile */}
            <div className="flex items-center space-x-3">
              <div className="hidden sm:block text-right">
                <p className="font-semibold text-white">{studentName}</p>
                <p className="text-white/60 text-sm">{rollNumber}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-xl">
                <User className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );

  // Profile Card
  const StudentProfileCard = ({
    name,
    rollNumber,
    className,
    semester,
    attendance,
    cgpa,
  }) => (
    <div className="mb-8 bg-white/10 backdrop-blur-sm border border-white/20 rounded-3xl p-6 shadow-xl">
      <div className="flex items-center space-x-4 mb-4">
        <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
          <User className="w-8 h-8 text-white" />
        </div>
        <div>
          <p className="font-bold text-white text-lg">{name}</p>
          <p className="text-white/60">{rollNumber}</p>
        </div>
      </div>
      <p className="text-white/70 text-sm mb-2">{className}</p>
      <p className="text-white/70 text-sm mb-4">{semester}</p>
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white/5 border border-white/10 rounded-2xl p-3">
          <p className="text-white/60 text-xs">Attendance</p>
          <p className="text-emerald-300 font-bold text-lg">{attendance}%</p>
        </div>
        <div className="bg-white/5 border border-white/10 rounded-2xl p-3">
          <p className="text-white/60 text-xs">CGPA</p>
          <p className="text-blue-300 font-bold text-lg">{cgpa}</p>
        </div>
      </div>
    </div>
  );

  // Navigation Item
  const NavigationItem = ({ item, isActive, onClick }) => (
    <button
      onClick={onClick}
      className={`w-full flex items-center space-x-4 px-4 py-4 rounded-2xl transition-all duration-300 ${
        isActive
          ? "bg-white/15 border border-white/20 shadow-lg"
          : "text-white/70 hover:bg-white/10 hover:text-white"
      }`}
    >
      <div
        className={`w-10 h-10 bg-gradient-to-r ${item.gradient} rounded-xl flex items-center justify-center shadow-lg`}
      >
        <item.icon className="w-5 h-5 text-white" />
      </div>
      <span className="font-medium text-white">{item.label}</span>
    </button>
  );

  // Dashboard Content
  const DashboardContent = () => (
    <div className="space-y-8">
      <h1 className="text-4xl font-bold bg-gradient-to-r from-white via-blue-100 to-cyan-200 bg-clip-text text-transparent">
        Welcome Back!
      </h1>
      <p className="text-blue-200/80">Here's your academic overview</p>
      {/* Add your stats + recent activity here (same as your code) */}
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return <SDashboard />;

      case "schedule":
        return <ScheduleTable />;

      case "attendance":
        return (
          <StudentAttendance
            weeklyData={weeklyData}
            overallAttendance={87}
            trend={"15%"}
            subjectData={subjectData}
            calendarData={calendarData}
          />
        );

      case "grades":
        return (
          <StudentGrades
            gpa={gpa}
            resultStatus={resultStatus}
            subjects={subjects}
          />
        );

case "assignments":
        return <StudentAssignments assignments={assignments} />;

        case "settings":
        return <SettingsComponent />;

      default:
        return (
          <div className="text-white text-center py-16">
            Content coming soon...
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-cyan-400/10 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Grid Overlay */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,255,255,0.3) 1px, transparent 0)`,
          backgroundSize: "24px 24px",
        }}
      ></div>

      {/* Header */}
      <Header
        onMenuClick={() => setSidebarOpen(true)}
        studentName={studentData.name}
        rollNumber={studentData.rollNumber}
      />

      <div className="relative z-10 flex">
        {/* Sidebar */}
        <nav className="hidden lg:block w-80 bg-white/5 backdrop-blur-xl border-r border-white/20 min-h-screen">
          <div className="p-8">
            <StudentProfileCard {...studentData} />
            <div className="space-y-3 mb-8">
              {navigationItems.map((item) => (
                <NavigationItem
                  key={item.id}
                  item={item}
                  isActive={activeTab === item.id}
                  onClick={() => setActiveTab(item.id)}
                />
              ))}
            </div>

            {/* System Status (Student Edition) */}
            <div className="bg-gradient-to-br from-blue-500/10 to-indigo-500/10 backdrop-blur-sm border border-blue-400/20 rounded-3xl p-6 shadow-xl">
              <h4 className="font-bold text-white mb-4 flex items-center">
                <Activity className="w-5 h-5 mr-2" />
                Portal Status
              </h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-white/70 text-sm">Server</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                    <span className="text-emerald-300 font-medium text-sm">
                      Online
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/70 text-sm">Assignments</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                    <span className="text-blue-300 font-medium text-sm">
                      Updated
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/70 text-sm">Library</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                    <span className="text-purple-300 font-medium text-sm">
                      Connected
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </nav>

        {/* Main */}
        <main className="flex-1 p-8 max-w-7xl mx-auto">{renderContent()}</main>
      </div>
    </div>
  );
}
