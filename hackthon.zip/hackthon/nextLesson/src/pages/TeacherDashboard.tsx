import { useState } from "react";
import {
  Calendar,
  Users,
  BarChart3,
  Bell,
  User,
  TrendingUp,
  Menu,
  X,
  UserCheck,
  Settings,
  MessageSquare,
  Activity,
} from "lucide-react";
import AttendanceComponent from "../components/Attendance";
import SchedulePage from "./Schedule";
import TDashboard from "../components/TeacherDashboard";
import Analytics from "../components/Analytics";
import ScheduleTable from "../components/ScheduleTable";
import StudentList from "../components/StudentList";
import SettingsComponent from "../components/Setting";

export default function TeacherDashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [classroomSignal, setClassroomSignal] = useState(false);

  // Sample data
  const teacherData = {
    name: "Dr. Priya Nair",
    employeeId: "CS2019008",
    department: "Computer Science & Engineering",
    currentClass: "Machine Learning - CS601",
    nextClass: "Data Mining - CS603",
    nextClassTime: "2:30 PM",
    studentsPresent: 42,
    totalStudents: 45,
    attendanceRate: 93.3,
  };

  const navigationItems = [
    {
      id: "dashboard",
      label: "Dashboard",
      icon: BarChart3,
      gradient: "from-blue-500 to-cyan-400",
    },
    {
      id: "attendance",
      label: "Live Attendance",
      icon: UserCheck,
      gradient: "from-emerald-500 to-teal-400",
    },
    {
      id: "schedule",
      label: "Schedule",
      icon: Calendar,
      gradient: "from-purple-500 to-pink-400",
    },
    {
      id: "analytics",
      label: "Analytics",
      icon: TrendingUp,
      gradient: "from-amber-500 to-orange-400",
    },
    {
      id: "students",
      label: "My Students",
      icon: Users,
      gradient: "from-rose-500 to-pink-400",
    },
    {
      id: "settings",
      label: "Settings",
      icon: Settings,
      gradient: "from-slate-500 to-gray-400",
    },
  ];

  const startClassroomSignal = () => {
    setClassroomSignal(true);
    setTimeout(() => {
      // Auto-stop after demo
    }, 3000);
  };

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return <TDashboard />;

      case "attendance":
        return <AttendanceComponent />;

      case "schedule":
        return <SchedulePage />;

      case "analytics":
        return <Analytics />;

      case "students":
        return(
          <StudentList />
        )

      case "settings":
        return (
          <SettingsComponent />
        )  

      default:
        return (
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl shadow-2xl p-8">
            <p className="text-white text-center">
              Content for {activeTab} coming soon...
            </p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-cyan-400/10 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Grid Pattern Overlay */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,255,255,0.3) 1px, transparent 0)`,
          backgroundSize: "24px 24px",
        }}
      ></div>

      {/* Header */}
      <header className="relative z-10 bg-white/5 backdrop-blur-xl border-b border-white/20 sticky top-0">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            {/* Logo and Mobile Menu */}
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-3 rounded-2xl text-white/70 hover:text-white hover:bg-white/10 transition-all duration-200"
              >
                <Menu className="w-6 h-6" />
              </button>
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-400 rounded-2xl flex items-center justify-center shadow-2xl">
                    <Calendar className="w-6 h-6 text-white" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-full flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  </div>
                </div>
                <div>
                  <span className="text-2xl font-bold bg-gradient-to-r from-white via-blue-100 to-cyan-200 bg-clip-text text-transparent">
                    NextLesson
                  </span>
                  <p className="text-blue-200/80 text-sm font-medium hidden sm:block">
                    Teacher Portal
                  </p>
                </div>
              </div>
            </div>

            {/* Right Side */}
            <div className="flex items-center space-x-4">
              {/* Live Status */}
              <div className="hidden sm:flex items-center space-x-3 px-4 py-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl">
                <div
                  className={`w-3 h-3 rounded-full ${
                    classroomSignal
                      ? "bg-emerald-400 animate-pulse shadow-lg shadow-emerald-400/50"
                      : "bg-white/40"
                  }`}
                ></div>
                <span className="text-sm text-white/90 font-medium">
                  {classroomSignal ? "Class Active" : "Offline"}
                </span>
              </div>

              {/* Notifications */}
              <button className="relative p-3 text-white/70 hover:text-white hover:bg-white/10 rounded-2xl transition-all duration-200 group">
                <Bell className="w-6 h-6" />
                <span className="absolute top-1 right-1 w-3 h-3 bg-gradient-to-r from-red-500 to-pink-400 rounded-full animate-pulse shadow-lg"></span>
              </button>

              {/* Profile */}
              <div className="flex items-center space-x-3">
                <div className="hidden sm:block text-right">
                  <p className="font-semibold text-white">{teacherData.name}</p>
                  <p className="text-white/60 text-sm">
                    {teacherData.department}
                  </p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center shadow-xl">
                  <User className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm"
            onClick={() => setSidebarOpen(false)}
          ></div>
          <div className="fixed inset-y-0 left-0 max-w-sm w-full bg-slate-900/95 backdrop-blur-xl shadow-2xl border-r border-white/20">
            <div className="flex items-center justify-between p-6 border-b border-white/20">
              <span className="text-xl font-bold text-white">Menu</span>
              <button
                onClick={() => setSidebarOpen(false)}
                className="p-2 rounded-2xl text-white/70 hover:text-white hover:bg-white/10 transition-all duration-200"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <nav className="p-6">
              <div className="space-y-3">
                {navigationItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setSidebarOpen(false);
                    }}
                    className={`w-full flex items-center space-x-4 px-4 py-3 rounded-2xl transition-all duration-300 group ${
                      activeTab === item.id
                        ? "bg-white/15 border border-white/20 shadow-lg"
                        : "text-white/70 hover:bg-white/10 hover:text-white"
                    }`}
                  >
                    <div
                      className={`w-10 h-10 bg-gradient-to-r ${item.gradient} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}
                    >
                      <item.icon className="w-5 h-5 text-white" />
                    </div>
                    <span className="font-medium">{item.label}</span>
                    {item.id === "attendance" && classroomSignal && (
                      <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse ml-auto"></div>
                    )}
                  </button>
                ))}
              </div>
            </nav>
          </div>
        </div>
      )}

      <div className="relative z-10 flex">
        {/* Desktop Sidebar */}
        <nav className="hidden lg:block w-80 bg-white/5 backdrop-blur-xl border-r border-white/20 min-h-screen">
          <div className="p-8">
            {/* Teacher Info */}
            <div className="mb-8 bg-white/10 backdrop-blur-sm border border-white/20 rounded-3xl p-6 shadow-xl">
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <User className="w-8 h-8 text-white" />
                </div>
                <div>
                  <p className="font-bold text-white text-lg">
                    {teacherData.name}
                  </p>
                  <p className="text-white/60">{teacherData.employeeId}</p>
                </div>
              </div>
              <p className="text-white/70 text-sm mb-4">
                {teacherData.department}
              </p>

              {/* Quick Actions */}
              <div className="space-y-3">
                <button
                  onClick={startClassroomSignal}
                  className={`w-full px-4 py-3 rounded-2xl font-semibold transition-all duration-300 transform hover:scale-105 ${
                    classroomSignal
                      ? "bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-400 hover:to-pink-400 text-white shadow-lg"
                      : "bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white shadow-lg"
                  }`}
                >
                  {classroomSignal ? "Stop Class Signal" : "Start Class Signal"}
                </button>
              </div>
            </div>

            {/* Navigation */}
            <div className="space-y-3 mb-8">
              {navigationItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center space-x-4 px-4 py-4 rounded-2xl transition-all duration-300 group ${
                    activeTab === item.id
                      ? "bg-white/15 border border-white/20 shadow-lg"
                      : "text-white/70 hover:bg-white/10 hover:text-white"
                  }`}
                >
                  <div
                    className={`w-10 h-10 bg-gradient-to-r ${item.gradient} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg`}
                  >
                    <item.icon className="w-5 h-5 text-white" />
                  </div>
                  <span className={`font-medium text-white`}>{item.label}</span>
                  {item.id === "attendance" && classroomSignal && (
                    <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse ml-auto shadow-lg shadow-emerald-400/50"></div>
                  )}
                </button>
              ))}
            </div>

            {/* System Status */}
            <div className="bg-gradient-to-br from-blue-500/10 to-indigo-500/10 backdrop-blur-sm border border-blue-400/20 rounded-3xl p-6 shadow-xl">
              <h4 className="font-bold text-white mb-4 flex items-center">
                <Activity className="w-5 h-5 mr-2" />
                System Status
              </h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-white/70 text-sm">CCTV System</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                    <span className="text-emerald-300 font-medium text-sm">
                      Active
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/70 text-sm">BLE Network</span>
                  <div className="flex items-center space-x-2">
                    <div
                      className={`w-2 h-2 rounded-full ${
                        classroomSignal
                          ? "bg-blue-400 animate-pulse"
                          : "bg-white/40"
                      }`}
                    ></div>
                    <span
                      className={`font-medium text-sm ${
                        classroomSignal ? "text-blue-300" : "text-white/60"
                      }`}
                    >
                      {classroomSignal ? "Broadcasting" : "Standby"}
                    </span>
                  </div>
                </div>
                {/* <div className="flex items-center justify-between">
                  <span className="text-white/70 text-sm">Wi-Fi RTT</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                    <span className="text-purple-300 font-medium text-sm">
                      Connected
                    </span>
                  </div>
                </div> */}
              </div>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-8 max-w-7xl mx-auto">{renderContent()}</main>
      </div>
    </div>
  );
}
