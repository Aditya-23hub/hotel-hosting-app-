import React from 'react';
import { CheckCircle, Calendar, Zap, Trophy } from 'lucide-react';

export const StatCard = ({ 
  title, 
  value, 
  icon: Icon, 
  gradient, 
  percentage, 
  additionalInfo,
  onClick 
}) => {
  return (
    <div className="group cursor-pointer" onClick={onClick}>
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-white/20 shadow-lg hover:shadow-2xl transition-all duration-300 group-hover:scale-105">
        <div className="flex items-center justify-between mb-4">
          <div className={`w-12 h-12 bg-gradient-to-r ${gradient} rounded-2xl flex items-center justify-center shadow-lg`}>
            <Icon className="w-6 h-6 text-white" />
          </div>
          {percentage && (
            <div className="text-right">
              <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className={`h-full bg-gradient-to-r ${gradient} rounded-full transition-all duration-1000`}
                  style={{ width: `${percentage}%` }}
                ></div>
              </div>
            </div>
          )}
          {additionalInfo && (
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
              <span className="text-xs font-bold text-blue-600">{additionalInfo}</span>
            </div>
          )}
        </div>
        <div>
          <p className="text-sm font-medium text-gray-600 mb-1">{title}</p>
          <p className={`text-3xl font-bold bg-gradient-to-r ${gradient.replace('from-', 'from-').replace('to-', 'to-')} bg-clip-text text-transparent`}>
            {value}
          </p>
        </div>
      </div>
    </div>
  );
};