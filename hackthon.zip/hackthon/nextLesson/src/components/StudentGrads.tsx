import React from "react";
import { Award, CheckCircle, XCircle, TrendingUp, BookOpen } from "lucide-react";

const StudentGrades = ({ gpa, resultStatus, subjects }) => {
  return (
    <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-3xl p-8 shadow-xl space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-2xl flex items-center justify-center shadow-lg">
            <Award className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Grades & Results</h3>
            <p className="text-white/60 text-sm">Academic performance summary</p>
          </div>
        </div>
        <div
          className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-sm font-medium ${
            resultStatus === "Pass"
              ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
              : "bg-red-500/20 text-red-300 border border-red-500/40"
          }`}
        >
          {resultStatus === "Pass" ? (
            <CheckCircle className="w-4 h-4" />
          ) : (
            <XCircle className="w-4 h-4" />
          )}
          <span>{resultStatus}</span>
        </div>
      </div>

      {/* GPA Summary */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-6 flex flex-col items-center justify-center text-center">
        <p className="text-white/60 text-sm">Overall GPA</p>
        <p className="text-5xl font-bold text-indigo-400 mt-2">{gpa}</p>
        <p className="text-white/40 text-xs mt-1">This Semester</p>
      </div>

      {/* Subject Grades */}
      <div>
        <div className="flex items-center space-x-2 mb-4">
          <BookOpen className="w-5 h-5 text-purple-400" />
          <h4 className="text-lg font-semibold text-white">
            Subject-wise Grades
          </h4>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {subjects.map((subj, idx) => (
            <div
              key={idx}
              className="bg-white/5 border border-white/10 rounded-2xl p-4 flex items-center justify-between"
            >
              <div>
                <p className="text-white font-medium">{subj.subject}</p>
                <p className="text-white/40 text-sm">{subj.credits} Credits</p>
              </div>
              <div
                className={`text-lg font-bold px-4 py-2 rounded-xl ${
                  subj.grade === "A+" || subj.grade === "A"
                    ? "bg-emerald-500/20 text-emerald-300"
                    : subj.grade === "B" || subj.grade === "B+"
                    ? "bg-yellow-500/20 text-yellow-300"
                    : "bg-red-500/20 text-red-300"
                }`}
              >
                {subj.grade}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StudentGrades;
