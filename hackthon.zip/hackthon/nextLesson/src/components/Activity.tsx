import React, { useState } from "react";
import {
  BookOpen,
  Play,
  Target,
  Clock,
  Star,
  TrendingUp,
  Award,
  CheckCircle,
  XCircle,
  RefreshCw,
  Filter,
  Search,
  Calendar,
  Users,
  Book,
  Video,
  FileText,
  Zap,
  Code,
} from "lucide-react";

export default function Activity() {
  const [activeFilter, setActiveFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  // Sample activity data
  const activities = [
    {
      id: 1,
      type: "quiz",
      title: "Machine Learning Fundamentals Quiz",
      subject: "Machine Learning",
      duration: "5 min",
      difficulty: "Easy",
      progress: 100,
      score: 85,
      status: "completed",
      completedAt: "2 hours ago",
      points: 25,
      description: "Test your understanding of basic ML concepts",
    },
    {
      id: 2,
      type: "reading",
      title: "Advanced Database Normalization",
      subject: "Database Systems",
      duration: "12 min",
      difficulty: "Medium",
      progress: 75,
      score: null,
      status: "in-progress",
      completedAt: null,
      points: 20,
      description: "Deep dive into 3NF and BCNF normalization techniques",
    },
    {
      id: 3,
      type: "video",
      title: "Dynamic Programming Explained",
      subject: "Data Structures & Algorithms",
      duration: "15 min",
      difficulty: "Hard",
      progress: 0,
      score: null,
      status: "recommended",
      completedAt: null,
      points: 35,
      description: "Master dynamic programming with practical examples",
    },
    {
      id: 4,
      type: "practice",
      title: "SQL Query Challenges",
      subject: "Database Systems",
      duration: "20 min",
      difficulty: "Medium",
      progress: 100,
      score: 92,
      status: "completed",
      completedAt: "1 day ago",
      points: 30,
      description: "Practice complex SQL queries and optimization",
    },
    {
      id: 5,
      type: "reading",
      title: "Software Design Patterns Guide",
      subject: "Software Engineering",
      duration: "18 min",
      difficulty: "Hard",
      progress: 40,
      score: null,
      status: "in-progress",
      completedAt: null,
      points: 40,
      description: "Learn essential design patterns for better code architecture",
    },
    {
      id: 6,
      type: "quiz",
      title: "Quick Python Syntax Check",
      subject: "Programming",
      duration: "3 min",
      difficulty: "Easy",
      progress: 0,
      score: null,
      status: "recommended",
      completedAt: null,
      points: 15,
      description: "Refresh your Python syntax knowledge",
    },
  ];

  const filters = [
    { id: "all", label: "All Activities", count: activities.length },
    {
      id: "recommended",
      label: "Recommended",
      count: activities.filter((a) => a.status === "recommended").length,
    },
    {
      id: "in-progress",
      label: "In Progress",
      count: activities.filter((a) => a.status === "in-progress").length,
    },
    {
      id: "completed",
      label: "Completed",
      count: activities.filter((a) => a.status === "completed").length,
    },
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "quiz":
        return Target;
      case "reading":
        return BookOpen;
      case "video":
        return Play;
      case "practice":
        return Code;
      default:
        return BookOpen;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-green-600 bg-green-50 border-green-200";
      case "in-progress":
        return "text-blue-600 bg-blue-50 border-blue-200";
      case "recommended":
        return "text-purple-600 bg-purple-50 border-purple-200";
      default:
        return "text-gray-600 bg-gray-50 border-gray-200";
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return "text-green-600 bg-green-100";
      case "Medium":
        return "text-yellow-600 bg-yellow-100";
      case "Hard":
        return "text-red-600 bg-red-100";
      default:
        return "text-gray-600 bg-gray-100";
    }
  };

  const filteredActivities = activities.filter((activity) => {
    const matchesFilter =
      activeFilter === "all" || activity.status === activeFilter;
    const matchesSearch =
      activity.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      activity.subject.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const totalPoints = activities
    .filter((a) => a.status === "completed")
    .reduce((sum, a) => sum + a.points, 0);

  const completedActivities = activities.filter(
    (a) => a.status === "completed"
  ).length;

  const avgScore =
    activities.filter((a) => a.score !== null).length > 0
      ? Math.round(
          activities
            .filter((a) => a.score !== null)
            .reduce((sum, a) => sum + a.score, 0) /
            activities.filter((a) => a.score !== null).length
        )
      : 0;

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Points</p>
              <p className="text-2xl font-bold text-purple-600">{totalPoints}</p>
            </div>
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <Star className="w-5 h-5 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Completed</p>
              <p className="text-2xl font-bold text-green-600">
                {completedActivities}
              </p>
            </div>
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg Score</p>
              <p className="text-2xl font-bold text-blue-600">{avgScore}%</p>
            </div>
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Streak</p>
              <p className="text-2xl font-bold text-orange-600">7 days</p>
            </div>
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm">
        <div className="p-6 border-b border-gray-100">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
            <h3 className="text-lg font-semibold text-gray-900">
              Learning Activities
            </h3>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search activities..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>
          
          {/* Filter Tabs */}
          <div className="flex space-x-1 mt-4 bg-gray-100 rounded-lg p-1">
            {filters.map((filter) => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id)}
                className={`flex-1 flex items-center justify-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeFilter === filter.id
                    ? "bg-white text-blue-600 shadow-sm"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                {filter.label}
                <span
                  className={`ml-2 px-2 py-0.5 rounded-full text-xs ${
                    activeFilter === filter.id
                      ? "bg-blue-100 text-blue-600"
                      : "bg-gray-200 text-gray-600"
                  }`}
                >
                  {filter.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Activities List */}
        <div className="p-6">
          <div className="space-y-4">
            {filteredActivities.map((activity) => {
              const IconComponent = getActivityIcon(activity.type);
              return (
                <div
                  key={activity.id}
                  className="border border-gray-200 rounded-xl p-6 hover:border-blue-300 transition-all hover:shadow-md"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-4 flex-1">
                      <div
                        className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                          activity.type === "quiz"
                            ? "bg-blue-100"
                            : activity.type === "reading"
                            ? "bg-green-100"
                            : activity.type === "video"
                            ? "bg-purple-100"
                            : "bg-orange-100"
                        }`}
                      >
                        <IconComponent
                          className={`w-6 h-6 ${
                            activity.type === "quiz"
                              ? "text-blue-600"
                              : activity.type === "reading"
                              ? "text-green-600"
                              : activity.type === "video"
                              ? "text-purple-600"
                              : "text-orange-600"
                          }`}
                        />
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-1">
                              {activity.title}
                            </h4>
                            <p className="text-sm text-gray-600 mb-2">
                              {activity.description}
                            </p>
                            <div className="flex items-center space-x-4 text-sm text-gray-600">
                              <span className="flex items-center">
                                <Book className="w-4 h-4 mr-1" />
                                {activity.subject}
                              </span>
                              <span className="flex items-center">
                                <Clock className="w-4 h-4 mr-1" />
                                {activity.duration}
                              </span>
                              <span
                                className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(
                                  activity.difficulty
                                )}`}
                              >
                                {activity.difficulty}
                              </span>
                              <span className="flex items-center">
                                <Star className="w-4 h-4 mr-1 text-yellow-500" />
                                {activity.points} pts
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Progress Bar */}
                        {activity.progress > 0 && (
                          <div className="mt-3">
                            <div className="flex items-center justify-between text-sm mb-1">
                              <span className="text-gray-600">Progress</span>
                              <span className="font-medium text-gray-900">
                                {activity.progress}%
                              </span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full ${
                                  activity.status === "completed"
                                    ? "bg-green-500"
                                    : "bg-blue-500"
                                }`}
                                style={{ width: `${activity.progress}%` }}
                              ></div>
                            </div>
                          </div>
                        )}

                        {/* Score and Status */}
                        <div className="flex items-center justify-between mt-3">
                          <div className="flex items-center space-x-3">
                            <span
                              className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(
                                activity.status
                              )}`}
                            >
                              {activity.status === "in-progress"
                                ? "In Progress"
                                : activity.status === "completed"
                                ? "Completed"
                                : "Recommended"}
                            </span>
                            {activity.score && (
                              <span className="text-sm font-medium text-green-600">
                                Score: {activity.score}%
                              </span>
                            )}
                            {activity.completedAt && (
                              <span className="text-xs text-gray-500">
                                {activity.completedAt}
                              </span>
                            )}
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            {activity.status === "completed" && (
                              <button className="px-3 py-1 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                                Review
                              </button>
                            )}
                            <button
                              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                                activity.status === "completed"
                                  ? "bg-gray-100 text-gray-600 hover:bg-gray-200"
                                  : "bg-blue-600 text-white hover:bg-blue-700"
                              }`}
                            >
                              {activity.status === "completed"
                                ? "Retake"
                                : activity.status === "in-progress"
                                ? "Continue"
                                : "Start"}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredActivities.length === 0 && (
            <div className="text-center py-12">
              <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No activities found
              </h3>
              <p className="text-gray-600">
                Try adjusting your search or filter criteria.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}