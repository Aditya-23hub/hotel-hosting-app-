import React from "react";
import { User, CheckCircle, XCircle, Clock } from "lucide-react";

const StudentList = () => {
  const students = [
    {
      name: "Alice Johnson",
      rollNo: "101",
      class: "10-A",
      status: "Present",
      attendance: 95,
    },
    {
      name: "Rahul Sharma",
      rollNo: "102",
      class: "10-A",
      status: "Absent",
      attendance: 72,
    },
    {
      name: "Sophia Williams",
      rollNo: "103",
      class: "10-A",
      status: "Late",
      attendance: 85,
    },
    {
      name: "Arjun Verma",
      rollNo: "104",
      class: "10-A",
      status: "Present",
      attendance: 98,
    },
  ];

  return (
    <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-3xl p-8 shadow-xl space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-2xl flex items-center justify-center shadow-lg">
          <User className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-white">Student List</h3>
          <p className="text-white/60 text-sm">Manage your classroom</p>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-left text-white/80">
          <thead>
            <tr className="text-white/60 text-sm border-b border-white/10">
              <th className="p-3">Roll No</th>
              <th className="p-3">Name</th>
              <th className="p-3">Class</th>
              <th className="p-3">Status</th>
              <th className="p-3">Attendance</th>
            </tr>
          </thead>
          <tbody>
            {students.map((student, idx) => (
              <tr
                key={idx}
                className="border-b border-white/10 hover:bg-white/5 transition"
              >
                <td className="p-3">{student.rollNo}</td>
                <td className="p-3 font-medium text-white">{student.name}</td>
                <td className="p-3">{student.class}</td>
                <td className="p-3">
                  <div
                    className={`flex items-center space-x-1 px-3 py-1 rounded-xl text-sm font-medium w-fit ${
                      student.status === "Present"
                        ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                        : student.status === "Late"
                        ? "bg-yellow-500/20 text-yellow-300 border border-yellow-500/40"
                        : "bg-red-500/20 text-red-300 border border-red-500/40"
                    }`}
                  >
                    {student.status === "Present" ? (
                      <CheckCircle className="w-4 h-4" />
                    ) : student.status === "Late" ? (
                      <Clock className="w-4 h-4" />
                    ) : (
                      <XCircle className="w-4 h-4" />
                    )}
                    <span>{student.status}</span>
                  </div>
                </td>
                <td className="p-3">
                  <div className="flex items-center space-x-2">
                    <div className="w-28 bg-white/10 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-2 rounded-full ${
                          student.attendance >= 90
                            ? "bg-emerald-400"
                            : student.attendance >= 75
                            ? "bg-yellow-400"
                            : "bg-red-400"
                        }`}
                        style={{ width: `${student.attendance}%` }}
                      />
                    </div>
                    <span className="text-white/70 text-sm">
                      {student.attendance}%
                    </span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default StudentList;
