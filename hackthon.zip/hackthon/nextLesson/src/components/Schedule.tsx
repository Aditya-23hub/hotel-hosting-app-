import React, { useState, useEffect } from "react";
import {
  Calendar,
  Clock,
  Users,
  BookOpen,
  AlertCircle,
  CheckCircle,
  XCircle,
  Bell,
  Filter,
  Settings,
  ChevronLeft,
  ChevronRight,
  Plus,
  Edit3,
  MapPin,
  User,
  Wifi,
  WifiOff,
} from "lucide-react";

const NextLessonSchedule = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [viewMode, setViewMode] = useState("week"); // 'day', 'week', 'month'
  const [userRole, setUserRole] = useState("student"); // 'student', 'teacher', 'admin'
  const [selectedClass, setSelectedClass] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [isOnline, setIsOnline] = useState(true);

  // Mock data for demonstration
  const [scheduleData, setScheduleData] = useState({
    classes: [
      {
        id: 1,
        subject: "Mathematics",
        teacher: "Dr. Priya Sharma",
        time: "09:00-10:00",
        room: "Room 101",
        status: "active", // 'active', 'cancelled', 'substitute', 'completed'
        attendance: { present: 28, total: 30, percentage: 93.3 },
        date: new Date().toISOString().split("T")[0],
        type: "regular",
        teacherPresent: true,
        smartActivities: [
          { id: 1, title: "Algebra Quiz", duration: "15 min", type: "quiz" },
          {
            id: 2,
            title: "Geometry Practice",
            duration: "20 min",
            type: "practice",
          },
        ],
      },
      {
        id: 2,
        subject: "Physics",
        teacher: "Prof. Rajesh Kumar",
        time: "10:15-11:15",
        room: "Lab 204",
        status: "substitute",
        attendance: { present: 25, total: 30, percentage: 83.3 },
        date: new Date().toISOString().split("T")[0],
        type: "regular",
        teacherPresent: false,
        substituteTeacher: "Dr. Meena Singh",
        smartActivities: [
          {
            id: 3,
            title: "Motion Laws Review",
            duration: "25 min",
            type: "video",
          },
          {
            id: 4,
            title: "Physics Problem Set",
            duration: "30 min",
            type: "practice",
          },
        ],
      },
      {
        id: 3,
        subject: "Free Period",
        teacher: null,
        time: "11:30-12:30",
        room: "Various",
        status: "active",
        attendance: null,
        date: new Date().toISOString().split("T")[0],
        type: "free",
        smartActivities: [
          {
            id: 5,
            title: "Library Study Group",
            duration: "60 min",
            type: "group",
          },
          {
            id: 6,
            title: "Career Counseling",
            duration: "30 min",
            type: "counseling",
          },
          {
            id: 7,
            title: "English Literature Club",
            duration: "45 min",
            type: "club",
          },
        ],
      },
      {
        id: 4,
        subject: "Chemistry",
        teacher: "Dr. Anita Verma",
        time: "13:30-14:30",
        room: "Lab 301",
        status: "completed",
        attendance: { present: 29, total: 30, percentage: 96.7 },
        date: new Date().toISOString().split("T")[0],
        type: "regular",
        teacherPresent: true,
        smartActivities: [],
      },
    ],
    holidays: [
      { date: "2024-12-25", name: "Christmas" },
      { date: "2025-01-01", name: "New Year" },
      { date: "2025-01-26", name: "Republic Day" },
    ],
  });

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      updateAttendanceData();
      checkTeacherPresence();
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const updateAttendanceData = () => {
    setScheduleData((prev) => ({
      ...prev,
      classes: prev.classes.map((cls) => ({
        ...cls,
        attendance: cls.attendance
          ? {
              ...cls.attendance,
              present: Math.min(
                cls.attendance.present + Math.floor(Math.random() * 2),
                cls.attendance.total
              ),
            }
          : null,
      })),
    }));
  };

  const checkTeacherPresence = () => {
    const currentTime = new Date();
    const currentHour = currentTime.getHours();

    setScheduleData((prev) => ({
      ...prev,
      classes: prev.classes.map((cls) => {
        const classHour = parseInt(cls.time.split(":")[0]);
        if (Math.abs(currentHour - classHour) <= 1) {
          return { ...cls, teacherPresent: Math.random() > 0.1 }; // 90% presence rate
        }
        return cls;
      }),
    }));
  };

  const getStatusColor = (status: any) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800 border-green-200";
      case "cancelled":
        return "bg-red-100 text-red-800 border-red-200";
      case "substitute":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "completed":
        return "bg-gray-100 text-gray-800 border-gray-200";
      default:
        return "bg-blue-100 text-blue-800 border-blue-200";
    }
  };

  const getStatusIcon = (status: string, teacherPresent: any) => {
    if (!teacherPresent && status === "active") {
      return <AlertCircle className="w-4 h-4 text-orange-500" />;
    }

    switch (status) {
      case "active":
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case "cancelled":
        return <XCircle className="w-4 h-4 text-red-500" />;
      case "substitute":
        return <AlertCircle className="w-4 h-4 text-yellow-500" />;
      case "completed":
        return <CheckCircle className="w-4 h-4 text-gray-500" />;
      default:
        return <Clock className="w-4 h-4 text-blue-500" />;
    }
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-IN", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const navigateDate = (direction: number) => {
    const newDate = new Date(selectedDate);
    if (viewMode === "day") {
      newDate.setDate(newDate.getDate() + direction);
    } else if (viewMode === "week") {
      newDate.setDate(newDate.getDate() + direction * 7);
    } else {
      newDate.setMonth(newDate.getMonth() + direction);
    }
    setSelectedDate(newDate);
  };

  const ClassCard = ({ classItem }) => (
    <div
      className={`p-4 rounded-lg border-2 transition-all duration-200 hover:shadow-lg cursor-pointer ${getStatusColor(
        classItem.status
      )}`}
      onClick={() => setSelectedClass(classItem)}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          {getStatusIcon(classItem.status, classItem.teacherPresent)}
          <h3 className="font-semibold text-lg">{classItem.subject}</h3>
        </div>
        <div className="flex items-center gap-1 text-sm text-gray-600">
          <Clock className="w-4 h-4" />
          {classItem.time}
        </div>
      </div>

      {classItem.teacher && (
        <div className="flex items-center gap-2 mb-2">
          <User className="w-4 h-4 text-gray-500" />
          <span className="text-sm">
            {classItem.teacherPresent
              ? classItem.teacher
              : classItem.substituteTeacher
              ? `Substitute: ${classItem.substituteTeacher}`
              : "Teacher Absent"}
          </span>
        </div>
      )}

      <div className="flex items-center gap-2 mb-3">
        <MapPin className="w-4 h-4 text-gray-500" />
        <span className="text-sm">{classItem.room}</span>
      </div>

      {classItem.attendance && (
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-gray-500" />
            <span className="text-sm">
              {classItem.attendance.present}/{classItem.attendance.total}{" "}
              present
            </span>
          </div>
          <span className="text-sm font-medium">
            {classItem.attendance.percentage.toFixed(1)}%
          </span>
        </div>
      )}

      {classItem.smartActivities.length > 0 && (
        <div className="border-t pt-3">
          <div className="flex items-center gap-2 mb-2">
            <BookOpen className="w-4 h-4 text-blue-500" />
            <span className="text-sm font-medium">Smart Activities</span>
          </div>
          <div className="space-y-1">
            {classItem.smartActivities
              .slice(0, 2)
              .map(
                (activity: {
                  id: React.Key | null | undefined;
                  title:
                    | string
                    | number
                    | bigint
                    | boolean
                    | React.ReactElement<
                        unknown,
                        string | React.JSXElementConstructor<any>
                      >
                    | Iterable<React.ReactNode>
                    | React.ReactPortal
                    | Promise<
                        | string
                        | number
                        | bigint
                        | boolean
                        | React.ReactPortal
                        | React.ReactElement<
                            unknown,
                            string | React.JSXElementConstructor<any>
                          >
                        | Iterable<React.ReactNode>
                        | null
                        | undefined
                      >
                    | null
                    | undefined;
                  duration:
                    | string
                    | number
                    | bigint
                    | boolean
                    | React.ReactElement<
                        unknown,
                        string | React.JSXElementConstructor<any>
                      >
                    | Iterable<React.ReactNode>
                    | React.ReactPortal
                    | Promise<
                        | string
                        | number
                        | bigint
                        | boolean
                        | React.ReactPortal
                        | React.ReactElement<
                            unknown,
                            string | React.JSXElementConstructor<any>
                          >
                        | Iterable<React.ReactNode>
                        | null
                        | undefined
                      >
                    | null
                    | undefined;
                }) => (
                  <div
                    key={activity.id}
                    className="flex items-center justify-between text-xs"
                  >
                    <span>{activity.title}</span>
                    <span className="text-gray-500">{activity.duration}</span>
                  </div>
                )
              )}
            {classItem.smartActivities.length > 2 && (
              <div className="text-xs text-blue-600">
                +{classItem.smartActivities.length - 2} more
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );

  const ClassModal = ({ classItem, onClose }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">{classItem.subject}</h2>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
            >
              <XCircle className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Class Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-3">
              <Clock className="w-5 h-5 text-blue-500" />
              <div>
                <div className="font-medium">Time</div>
                <div className="text-gray-600">{classItem.time}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-blue-500" />
              <div>
                <div className="font-medium">Location</div>
                <div className="text-gray-600">{classItem.room}</div>
              </div>
            </div>
          </div>

          {/* Teacher Info */}
          {classItem.teacher && (
            <div className="flex items-center gap-3">
              <User className="w-5 h-5 text-blue-500" />
              <div>
                <div className="font-medium">Teacher</div>
                <div className="text-gray-600">
                  {classItem.teacherPresent
                    ? classItem.teacher
                    : classItem.substituteTeacher
                    ? `Substitute: ${classItem.substituteTeacher}`
                    : "Teacher Absent"}
                </div>
              </div>
            </div>
          )}

          {/* Attendance */}
          {classItem.attendance && (
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-medium mb-3 flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-500" />
                Attendance
              </h3>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold">
                    {classItem.attendance.present}
                  </div>
                  <div className="text-sm text-gray-600">
                    out of {classItem.attendance.total}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-green-600">
                    {classItem.attendance.percentage.toFixed(1)}%
                  </div>
                  <div className="text-sm text-gray-600">Present</div>
                </div>
              </div>
            </div>
          )}

          {/* Smart Activities */}
          {classItem.smartActivities.length > 0 && (
            <div>
              <h3 className="font-medium mb-3 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-blue-500" />
                Available Activities
              </h3>
              <div className="space-y-3">
                {classItem.smartActivities.map(
                  (activity: {
                    id: React.Key | null | undefined;
                    title:
                      | string
                      | number
                      | bigint
                      | boolean
                      | React.ReactElement<
                          unknown,
                          string | React.JSXElementConstructor<any>
                        >
                      | Iterable<React.ReactNode>
                      | React.ReactPortal
                      | Promise<
                          | string
                          | number
                          | bigint
                          | boolean
                          | React.ReactPortal
                          | React.ReactElement<
                              unknown,
                              string | React.JSXElementConstructor<any>
                            >
                          | Iterable<React.ReactNode>
                          | null
                          | undefined
                        >
                      | null
                      | undefined;
                    type:
                      | string
                      | number
                      | bigint
                      | boolean
                      | React.ReactElement<
                          unknown,
                          string | React.JSXElementConstructor<any>
                        >
                      | Iterable<React.ReactNode>
                      | React.ReactPortal
                      | Promise<
                          | string
                          | number
                          | bigint
                          | boolean
                          | React.ReactPortal
                          | React.ReactElement<
                              unknown,
                              string | React.JSXElementConstructor<any>
                            >
                          | Iterable<React.ReactNode>
                          | null
                          | undefined
                        >
                      | null
                      | undefined;
                    duration:
                      | string
                      | number
                      | bigint
                      | boolean
                      | React.ReactElement<
                          unknown,
                          string | React.JSXElementConstructor<any>
                        >
                      | Iterable<React.ReactNode>
                      | React.ReactPortal
                      | Promise<
                          | string
                          | number
                          | bigint
                          | boolean
                          | React.ReactPortal
                          | React.ReactElement<
                              unknown,
                              string | React.JSXElementConstructor<any>
                            >
                          | Iterable<React.ReactNode>
                          | null
                          | undefined
                        >
                      | null
                      | undefined;
                  }) => (
                    <div
                      key={activity.id}
                      className="border rounded-lg p-3 hover:bg-gray-50"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-medium">{activity.title}</div>
                          <div className="text-sm text-gray-600 capitalize">
                            {activity.type}
                          </div>
                        </div>
                        <div className="text-sm text-blue-600">
                          {activity.duration}
                        </div>
                      </div>
                    </div>
                  )
                )}
              </div>
            </div>
          )}

          {/* Actions */}
          {userRole === "teacher" && (
            <div className="flex gap-3">
              <button className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
                Start Class
              </button>
              <button className="flex-1 bg-gray-600 text-white py-2 px-4 rounded-lg hover:bg-gray-700 transition-colors">
                Mark Complete
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="bg-blue-600 text-white p-3 rounded-lg">
                <Calendar className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  NextLesson Schedule
                </h1>
                <p className="text-gray-600">{formatDate(selectedDate)}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {isOnline ? (
                <div className="flex items-center gap-2 text-green-600">
                  <Wifi className="w-5 h-5" />
                  <span className="text-sm">Online</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-red-600">
                  <WifiOff className="w-5 h-5" />
                  <span className="text-sm">Offline</span>
                </div>
              )}
              <select
                value={userRole}
                onChange={(e) => setUserRole(e.target.value)}
                className="px-3 py-2 border rounded-lg"
              >
                <option value="student">Student</option>
                <option value="teacher">Teacher</option>
                <option value="admin">Admin</option>
              </select>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                onClick={() => navigateDate(-1)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => navigateDate(1)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
              <button
                onClick={() => setSelectedDate(new Date())}
                className="px-4 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-colors"
              >
                Today
              </button>
            </div>

            <div className="flex items-center gap-2">
              {["day", "week", "month"].map((mode) => (
                <button
                  key={mode}
                  onClick={() => setViewMode(mode)}
                  className={`px-4 py-2 rounded-lg transition-colors capitalize ${
                    viewMode === mode
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Schedule Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {scheduleData.classes.map((classItem) => (
            <ClassCard key={classItem.id} classItem={classItem} />
          ))}
        </div>

        {/* Quick Stats */}
        <div className="bg-white rounded-xl shadow-lg p-6 mt-6">
          <h2 className="text-xl font-bold mb-4">Today's Summary</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {scheduleData.classes.length}
              </div>
              <div className="text-sm text-gray-600">Total Classes</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {
                  scheduleData.classes.filter((c) => c.status === "completed")
                    .length
                }
              </div>
              <div className="text-sm text-gray-600">Completed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">
                {
                  scheduleData.classes.filter((c) => c.status === "substitute")
                    .length
                }
              </div>
              <div className="text-sm text-gray-600">Substitutes</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {scheduleData.classes.reduce(
                  (acc, c) => acc + (c.smartActivities?.length || 0),
                  0
                )}
              </div>
              <div className="text-sm text-gray-600">Smart Activities</div>
            </div>
          </div>
        </div>

        {/* Class Modal */}
        {selectedClass && (
          <ClassModal
            classItem={selectedClass}
            onClose={() => setSelectedClass(null)}
          />
        )}
      </div>
    </div>
  );
};

export default NextLessonSchedule;
