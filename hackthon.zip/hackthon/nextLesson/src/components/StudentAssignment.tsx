import React from "react";
import { FileText, Clock, CheckCircle, XCircle, BookOpen } from "lucide-react";

const StudentAssignments = ({ assignments }) => {
  return (
    <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-3xl p-8 shadow-xl space-y-8">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-rose-500 rounded-2xl flex items-center justify-center shadow-lg">
          <FileText className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-white">Assignments</h3>
          <p className="text-white/60 text-sm">Track your submissions</p>
        </div>
      </div>

      {/* List of Assignments */}
      <div className="space-y-4">
        {assignments.map((assignment, idx) => (
          <div
            key={idx}
            className="bg-white/5 border border-white/10 rounded-2xl p-5 flex items-center justify-between hover:scale-[1.01] transition-transform"
          >
            {/* Left - Assignment Info */}
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center shadow-lg">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-white font-medium">{assignment.title}</p>
                <p className="text-white/40 text-sm">
                  Due: {assignment.dueDate}
                </p>
              </div>
            </div>

            {/* Right - Status & Progress */}
            <div className="flex items-center space-x-4">
              <div
                className={`flex items-center space-x-1 px-3 py-1 rounded-xl text-sm font-medium ${
                  assignment.status === "Submitted"
                    ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                    : assignment.status === "Pending"
                    ? "bg-yellow-500/20 text-yellow-300 border border-yellow-500/40"
                    : "bg-red-500/20 text-red-300 border border-red-500/40"
                }`}
              >
                {assignment.status === "Submitted" ? (
                  <CheckCircle className="w-4 h-4" />
                ) : assignment.status === "Pending" ? (
                  <Clock className="w-4 h-4" />
                ) : (
                  <XCircle className="w-4 h-4" />
                )}
                <span>{assignment.status}</span>
              </div>

              {/* Progress Bar */}
              <div className="w-28 bg-white/10 rounded-full h-2 overflow-hidden">
                <div
                  className={`h-2 rounded-full ${
                    assignment.progress >= 80
                      ? "bg-emerald-400"
                      : assignment.progress >= 50
                      ? "bg-yellow-400"
                      : "bg-red-400"
                  }`}
                  style={{ width: `${assignment.progress}%` }}
                />
              </div>
              <span className="text-white/70 text-sm">
                {assignment.progress}%
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StudentAssignments;
