import React, { useState } from 'react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
  RadialBarChart,
  RadialBar
} from 'recharts';
import {
  TrendingUp,
  Users,
  Clock,
  BookOpen,
  Target,
  Award,
  Activity,
  Calendar,
  Eye,
  UserCheck,
  Brain,
  Zap
} from 'lucide-react';

const Analytics = () => {
  const [timeRange, setTimeRange] = useState('week');

  // Sample data for different metrics
  const attendanceData = [
    { day: 'Mon', present: 85, absent: 15, late: 5 },
    { day: 'Tue', present: 92, absent: 8, late: 3 },
    { day: 'Wed', present: 88, absent: 12, late: 7 },
    { day: 'Thu', present: 90, absent: 10, late: 4 },
    { day: 'Fri', present: 87, absent: 13, late: 6 },
    { day: 'Sat', present: 82, absent: 18, late: 8 }
  ];

  const engagementData = [
    { time: '09:00', engagement: 65, activities: 12 },
    { time: '10:00', engagement: 78, activities: 18 },
    { time: '11:00', engagement: 85, activities: 22 },
    { time: '12:00', engagement: 72, activities: 15 },
    { time: '13:00', engagement: 45, activities: 8 },
    { time: '14:00', engagement: 82, activities: 20 },
    { time: '15:00', engagement: 88, activities: 25 },
    { time: '16:00', engagement: 75, activities: 16 }
  ];

  const subjectPerformance = [
    { subject: 'Mathematics', score: 85, completion: 78 },
    { subject: 'Physics', score: 92, completion: 85 },
    { subject: 'Chemistry', score: 88, completion: 82 },
    { subject: 'English', score: 90, completion: 88 },
    { subject: 'History', score: 87, completion: 75 },
    { subject: 'Biology', score: 83, completion: 79 }
  ];

  const learningMethods = [
    { name: 'Face Recognition', value: 35, color: '#10b981' },
    { name: 'BLE Proximity', value: 28, color: '#3b82f6' },
    { name: 'Wi-Fi RTT', value: 22, color: '#8b5cf6' },
    { name: 'QR Codes', value: 15, color: '#f59e0b' }
  ];

  const weeklyProgress = [
    { week: 'W1', attendance: 82, engagement: 75, performance: 78 },
    { week: 'W2', attendance: 85, engagement: 80, performance: 82 },
    { week: 'W3', attendance: 88, engagement: 85, performance: 85 },
    { week: 'W4', attendance: 90, engagement: 88, performance: 88 }
  ];

  const stats = [
    {
      title: 'Total Students',
      value: '2,847',
      change: '+12%',
      icon: Users,
      gradient: 'from-emerald-500 to-teal-500',
      bgGradient: 'from-emerald-500/10 to-teal-500/10',
      borderColor: 'border-emerald-400/20'
    },
    {
      title: 'Avg Attendance',
      value: '88.2%',
      change: '+5.2%',
      icon: UserCheck,
      gradient: 'from-blue-500 to-cyan-500',
      bgGradient: 'from-blue-500/10 to-cyan-500/10',
      borderColor: 'border-blue-400/20'
    },
    {
      title: 'Engagement Rate',
      value: '76.8%',
      change: '+8.1%',
      icon: Brain,
      gradient: 'from-purple-500 to-indigo-500',
      bgGradient: 'from-purple-500/10 to-indigo-500/10',
      borderColor: 'border-purple-400/20'
    },
    {
      title: 'Time Saved',
      value: '245h',
      change: '+15%',
      icon: Clock,
      gradient: 'from-orange-500 to-red-500',
      bgGradient: 'from-orange-500/10 to-red-500/10',
      borderColor: 'border-orange-400/20'
    }
  ];

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-800/95 backdrop-blur-xl border border-white/20 rounded-2xl p-4 shadow-2xl">
          <p className="text-white font-semibold mb-2">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-sm text-white" style={{ color: entry.color }}>
              {`${entry.dataKey}: ${entry.value}${entry.dataKey.includes('Rate') || entry.dataKey.includes('score') ? '%' : ''}`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-white via-blue-100 to-cyan-200 bg-clip-text text-transparent mb-2">
            Analytics Dashboard
          </h1>
          <p className="text-white/70 text-lg">
            Comprehensive insights into classroom performance and engagement
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white focus:outline-none focus:ring-2 focus:ring-blue-400/50 focus:border-blue-400/50"
          >
            <option value="week">This Week</option>
            <option value="month">This Month</option>
            <option value="semester">This Semester</option>
            <option value="year">This Year</option>
          </select>
        </div>
      </div>

      {/* Key Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div
            key={index}
            className={`bg-gradient-to-br ${stat.bgGradient} backdrop-blur-sm border ${stat.borderColor} rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105`}
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 bg-gradient-to-r ${stat.gradient} rounded-2xl flex items-center justify-center shadow-lg`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
              <div className="flex items-center space-x-1 text-emerald-300 text-sm font-medium">
                <TrendingUp className="w-4 h-4" />
                <span>{stat.change}</span>
              </div>
            </div>
            <div>
              <p className="text-white/60 text-sm font-medium mb-1">{stat.title}</p>
              <p className="text-3xl font-bold text-white">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Main Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Attendance Trends */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-3xl p-8 shadow-xl">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white">Attendance Trends</h3>
            </div>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={attendanceData}>
                <defs>
                  <linearGradient id="attendanceGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="day" stroke="rgba(255,255,255,0.6)" />
                <YAxis stroke="rgba(255,255,255,0.6)" />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="present"
                  stroke="#10b981"
                  strokeWidth={3}
                  fill="url(#attendanceGradient)"
                />
                <Line type="monotone" dataKey="late" stroke="#f59e0b" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Engagement Over Time */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-3xl p-8 shadow-xl">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white">Daily Engagement</h3>
            </div>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={engagementData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="time" stroke="rgba(255,255,255,0.6)" />
                <YAxis stroke="rgba(255,255,255,0.6)" />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="engagement"
                  stroke="#3b82f6"
                  strokeWidth={3}
                  dot={{ fill: '#3b82f6', strokeWidth: 2, r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="activities"
                  stroke="#06b6d4"
                  strokeWidth={2}
                  dot={{ fill: '#06b6d4', strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Second Row of Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Subject Performance */}
        <div className="lg:col-span-2 bg-white/5 backdrop-blur-xl border border-white/20 rounded-3xl p-8 shadow-xl">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-xl flex items-center justify-center shadow-lg">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white">Subject Performance</h3>
            </div>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={subjectPerformance}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="subject" stroke="rgba(255,255,255,0.6)" />
                <YAxis stroke="rgba(255,255,255,0.6)" />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="score" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
                <Bar dataKey="completion" fill="#06b6d4" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Attendance Methods Distribution */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-3xl p-8 shadow-xl">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center shadow-lg">
              <Eye className="w-5 h-5 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white">Tracking Methods</h3>
          </div>
          <div className="h-64 mb-4">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={learningMethods}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  stroke="none"
                >
                  {learningMethods.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-3">
            {learningMethods.map((method, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: method.color }}
                  ></div>
                  <span className="text-white/80 text-sm">{method.name}</span>
                </div>
                <span className="text-white font-semibold text-sm">{method.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Weekly Progress Overview */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-3xl p-8 shadow-xl">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-blue-500 rounded-xl flex items-center justify-center shadow-lg">
            <Calendar className="w-5 h-5 text-white" />
          </div>
          <h3 className="text-xl font-bold text-white">Weekly Progress Overview</h3>
        </div>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={weeklyProgress}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="week" stroke="rgba(255,255,255,0.6)" />
              <YAxis stroke="rgba(255,255,255,0.6)" />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Line
                type="monotone"
                dataKey="attendance"
                stroke="#10b981"
                strokeWidth={3}
                name="Attendance Rate"
                dot={{ fill: '#10b981', strokeWidth: 2, r: 6 }}
              />
              <Line
                type="monotone"
                dataKey="engagement"
                stroke="#3b82f6"
                strokeWidth={3}
                name="Engagement Rate"
                dot={{ fill: '#3b82f6', strokeWidth: 2, r: 6 }}
              />
              <Line
                type="monotone"
                dataKey="performance"
                stroke="#8b5cf6"
                strokeWidth={3}
                name="Performance Score"
                dot={{ fill: '#8b5cf6', strokeWidth: 2, r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* AI Insights Panel */}
      <div className="bg-gradient-to-br from-emerald-500/10 to-blue-500/10 backdrop-blur-xl border border-emerald-400/20 rounded-3xl p-8 shadow-xl">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-blue-500 rounded-xl flex items-center justify-center shadow-lg">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <h3 className="text-xl font-bold text-white">AI-Powered Insights</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-3">
              <Target className="w-6 h-6 text-emerald-400" />
              <h4 className="font-semibold text-white">Peak Performance</h4>
            </div>
            <p className="text-white/70 text-sm mb-2">
              Students show highest engagement between 11:00 AM - 3:00 PM
            </p>
            <div className="text-emerald-300 text-xs font-medium">88% correlation</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-3">
              <Award className="w-6 h-6 text-blue-400" />
              <h4 className="font-semibold text-white">Improvement Trend</h4>
            </div>
            <p className="text-white/70 text-sm mb-2">
              Mathematics scores increased by 15% after implementing micro-lessons
            </p>
            <div className="text-blue-300 text-xs font-medium">+15% improvement</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-3">
              <Users className="w-6 h-6 text-purple-400" />
              <h4 className="font-semibold text-white">At-Risk Students</h4>
            </div>
            <p className="text-white/70 text-sm mb-2">
              12 students with attendance below 70% need intervention
            </p>
            <div className="text-purple-300 text-xs font-medium">Immediate action needed</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;