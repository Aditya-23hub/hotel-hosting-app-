import { User } from 'lucide-react';

export const StudentProfileCard = ({ 
  name, 
  rollNumber, 
  className, 
  attendance 
}) => {
  return (
    <div className="mb-8 p-6 bg-gradient-to-br from-blue-500 via-purple-500 to-indigo-600 rounded-3xl text-white shadow-xl">
      <div className="flex items-center space-x-4 mb-4">
        <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center border border-white/30">
          <User className="w-8 h-8 text-white" />
        </div>
        <div>
          <p className="text-lg font-bold">{name}</p>
          <p className="text-blue-100">{rollNumber}</p>
        </div>
      </div>
      <div className="space-y-2">
        <p className="text-sm text-blue-100">{className}</p>
        <div className="flex items-center justify-between text-sm">
          <span className="text-blue-100">Overall Progress</span>
          <span className="font-semibold">{attendance}%</span>
        </div>
        <div className="w-full bg-white/20 rounded-full h-2">
          <div 
            className="h-2 bg-gradient-to-r from-cyan-400 to-blue-300 rounded-full transition-all duration-1000"
            style={{ width: `${attendance}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
};