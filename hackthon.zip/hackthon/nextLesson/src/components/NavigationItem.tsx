export const NavigationItem = ({ 
  item, 
  isActive, 
  onClick 
}) => {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center space-x-4 px-4 py-4 rounded-2xl transition-all duration-300 group ${
        isActive
          ? `bg-gradient-to-r ${item.gradient} text-white shadow-xl scale-105`
          : "text-gray-700 hover:bg-white/60 hover:scale-105"
      }`}
    >
      <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
        isActive 
          ? "bg-white/20" 
          : "bg-gray-100 group-hover:bg-white"
      }`}>
        <item.icon className="w-4 h-4" />
      </div>
      <span className="font-medium">{item.label}</span>
      {isActive && (
        <div className="ml-auto w-2 h-2 bg-white rounded-full animate-pulse"></div>
      )}
    </button>
  );
};