import { CheckCircle, Play, Clock, Activity } from 'lucide-react';

export const ScheduleCard = ({ scheduleItems, completedClasses, totalClasses }) => {
  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-3xl border border-white/20 shadow-xl overflow-hidden">
      <div className="p-8 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Today's Schedule</h3>
            <p className="text-gray-600">Track your daily progress</p>
          </div>
          <div className="flex items-center space-x-2 px-4 py-2 bg-blue-50 rounded-full">
            <Activity className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium text-blue-600">{completedClasses}/{totalClasses} completed</span>
          </div>
        </div>
      </div>
      <div className="p-8">
        <div className="space-y-4">
          {scheduleItems.map((item, index) => (
            <div
              key={index}
              className={`relative p-6 rounded-2xl border transition-all duration-300 hover:shadow-lg ${
                item.status === "completed"
                  ? "bg-green-50 border-green-200"
                  : item.status === "current"
                  ? "bg-blue-50 border-blue-300 shadow-lg scale-105"
                  : "bg-gray-50 border-gray-200"
              }`}
            >
              {item.status === "current" && (
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-blue-500 rounded-full animate-pulse"></div>
              )}
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                    item.status === "completed"
                      ? "bg-green-500"
                      : item.status === "current"
                      ? "bg-blue-500"
                      : "bg-gray-400"
                  }`}>
                    {item.status === "completed" ? (
                      <CheckCircle className="w-6 h-6 text-white" />
                    ) : item.status === "current" ? (
                      <Play className="w-6 h-6 text-white" />
                    ) : (
                      <Clock className="w-6 h-6 text-white" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900">{item.subject}</h4>
                    <p className="text-gray-600">{item.teacher} • {item.room}</p>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className={`px-3 py-1 rounded-full text-sm font-medium mb-2 ${
                    item.status === "current" 
                      ? "bg-blue-500 text-white" 
                      : "bg-gray-200 text-gray-700"
                  }`}>
                    {item.time}
                  </div>
                  {item.attendance !== null && (
                    <div className={`text-xs px-2 py-1 rounded-full ${
                      item.attendance
                        ? "bg-green-100 text-green-700"
                        : "bg-red-100 text-red-700"
                    }`}>
                      {item.attendance ? "Present ✓" : "Absent ✗"}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};