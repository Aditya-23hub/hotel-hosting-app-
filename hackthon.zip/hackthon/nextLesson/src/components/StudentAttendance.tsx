import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
} from "recharts";
import { Activity, TrendingUp, Calendar, BookOpen } from "lucide-react";

// Custom Tooltip for Chart
const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-800/95 backdrop-blur-xl border border-white/20 rounded-2xl p-4 shadow-2xl">
        <p className="text-white font-semibold mb-2">{label}</p>
        {payload.map((entry, index) => (
          <p key={index} className="text-sm text-white" style={{ color: entry.color }}>
            {`${entry.dataKey}: ${entry.value}%`}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

const StudentAttendance = ({
  weeklyData,
  overallAttendance,
  trend,
  subjectData,
  calendarData,
}) => {
  return (
    <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-3xl p-8 shadow-xl space-y-10">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-2xl flex items-center justify-center shadow-lg">
            <Activity className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Attendance</h3>
            <p className="text-white/60 text-sm">Weekly & Subject Breakdown</p>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-emerald-300 font-medium">
          <TrendingUp className="w-4 h-4" />
          <span>{trend}</span>
        </div>
      </div>

      {/* Stat Summary */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-6 flex flex-col items-center justify-center text-center">
        <p className="text-white/60 text-sm">Overall Attendance</p>
        <p className="text-4xl font-bold text-emerald-400 mt-2">
          {overallAttendance}%
        </p>
        <p className="text-white/40 text-xs mt-1">This Semester</p>
      </div>

      {/* Weekly Chart */}
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={weeklyData}>
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="rgba(255,255,255,0.1)"
            />
            <XAxis dataKey="week" stroke="rgba(255,255,255,0.6)" />
            <YAxis stroke="rgba(255,255,255,0.6)" />
            <Tooltip content={<CustomTooltip />} />
            <Line
              type="monotone"
              dataKey="attendance"
              stroke="#10b981"
              strokeWidth={3}
              dot={{ fill: "#10b981", r: 6 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Subject-wise Attendance */}
      <div>
        <div className="flex items-center space-x-2 mb-4">
          <BookOpen className="w-5 h-5 text-indigo-400" />
          <h4 className="text-lg font-semibold text-white">
            Subject-wise Attendance
          </h4>
        </div>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={subjectData}>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="rgba(255,255,255,0.1)"
              />
              <XAxis dataKey="subject" stroke="rgba(255,255,255,0.6)" />
              <YAxis stroke="rgba(255,255,255,0.6)" />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="attendance" radius={[10, 10, 0, 0]}>
                {subjectData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={
                      entry.attendance >= 85
                        ? "#10b981"
                        : entry.attendance >= 70
                        ? "#facc15"
                        : "#ef4444"
                    }
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Calendar Attendance */}
      <div>
        <div className="flex items-center space-x-2 mb-4">
          <Calendar className="w-5 h-5 text-cyan-400" />
          <h4 className="text-lg font-semibold text-white">Calendar View: September</h4>
        </div>
        <div className="grid grid-cols-7 gap-2 text-center text-sm">
          {calendarData.map((day, idx) => (
            <div
              key={idx}
              className={`p-3 rounded-xl ${
                day.present
                  ? "bg-emerald-500/20 border border-emerald-500/40 text-emerald-300"
                  : "bg-red-500/20 border border-red-500/40 text-red-300"
              }`}
            >
              {day.date}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StudentAttendance;
