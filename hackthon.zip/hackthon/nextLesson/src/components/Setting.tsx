import React from "react";
import { User, Lock, Settings, LogOut, Mail, Phone } from "lucide-react";
import { useNavigate } from "react-router-dom";

const SettingsComponent = () => {
    const navigate = useNavigate();
  return (
    <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-3xl p-8 shadow-xl space-y-8">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <div className="w-12 h-12 bg-gradient-to-r from-teal-500 to-emerald-500 rounded-2xl flex items-center justify-center shadow-lg">
          <Settings className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-white">Settings</h3>
          <p className="text-white/60 text-sm">
            Manage your account & preferences
          </p>
        </div>
      </div>

      {/* Account Info */}
      <div className="space-y-4">
        <h4 className="text-white/70 font-semibold">Account Information</h4>
        <div className="bg-white/5 border border-white/10 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <User className="w-5 h-5 text-white/60" />
              <span className="text-white">John Doe</span>
            </div>
            <button className="px-3 py-1 rounded-lg bg-white/10 text-white text-sm hover:bg-white/20 transition">
              Edit
            </button>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Mail className="w-5 h-5 text-white/60" />
              <span className="text-white">john.doe@example.com</span>
            </div>
            <button className="px-3 py-1 rounded-lg bg-white/10 text-white text-sm hover:bg-white/20 transition">
              Change
            </button>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Phone className="w-5 h-5 text-white/60" />
              <span className="text-white">+91 98765 43210</span>
            </div>
            <button className="px-3 py-1 rounded-lg bg-white/10 text-white text-sm hover:bg-white/20 transition">
              Update
            </button>
          </div>
        </div>
      </div>

      {/* Security */}
      <div className="space-y-4">
        <h4 className="text-white/70 font-semibold">Security</h4>
        <div className="bg-white/5 border border-white/10 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Lock className="w-5 h-5 text-white/60" />
              <span className="text-white">Change Password</span>
            </div>
            <button className="px-3 py-1 rounded-lg bg-white/10 text-white text-sm hover:bg-white/20 transition">
              Update
            </button>
          </div>
        </div>
      </div>

      {/* Preferences */}
      <div className="space-y-4">
        <h4 className="text-white/70 font-semibold">Preferences</h4>
        <div className="bg-white/5 border border-white/10 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-white">Dark Mode</span>
            <input
              type="checkbox"
              className="w-5 h-5 accent-emerald-500"
              defaultChecked
            />
          </div>
          <div className="flex items-center justify-between">
            <span className="text-white">Email Notifications</span>
            <input type="checkbox" className="w-5 h-5 accent-emerald-500" />
          </div>
        </div>
      </div>

      {/* Logout */}
      <div className="flex justify-end">
        <button onClick={() => {
          // Handle logout
          console.log("Logout clicked");
          navigate("/");
        }} className="px-4 py-2 rounded-xl bg-red-500/20 text-red-300 border border-red-500/40 hover:bg-red-500/30 flex items-center space-x-2 transition">
          <LogOut className="w-5 h-5" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};

export default SettingsComponent;
