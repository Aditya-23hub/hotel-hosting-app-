import { ChevronRight } from 'lucide-react';

export const QuickActionCard = ({ 
  icon: Icon, 
  title, 
  description, 
  gradient, 
  onClick 
}) => {
  return (
    <div 
      onClick={onClick}
      className={`group cursor-pointer bg-gradient-to-br ${gradient} rounded-2xl p-6 text-white hover:scale-105 transition-all duration-300`}
    >
      <div className="flex items-center justify-between mb-4">
        <Icon className="w-8 h-8" />
        <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-opacity-80">{description}</p>
    </div>
  );
};