import { Zap, Target, Clock } from 'lucide-react';

export const WelcomeCard = ({ 
  studentName, 
  streak, 
  weeklyGoal, 
  currentWeekAttendance, 
  nextClass, 
  nextClassTime 
}) => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-700 rounded-3xl p-8 text-white">
      <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-white/10 rounded-full blur-xl"></div>
      <div className="absolute bottom-0 left-0 -mb-8 -ml-8 w-32 h-32 bg-cyan-400/20 rounded-full blur-2xl"></div>
      
      <div className="relative flex items-center justify-between">
        <div className="space-y-4">
          <div>
            <h2 className="text-3xl font-bold mb-2">
              Good morning, {studentName.split(" ")[0]}! 👋
            </h2>
            <p className="text-blue-100 text-lg">
              You're doing great! Keep up the momentum.
            </p>
          </div>
          
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                <Zap className="w-4 h-4 text-yellow-300" />
              </div>
              <div>
                <p className="text-sm text-blue-100">Study Streak</p>
                <p className="font-semibold">{streak} days</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                <Target className="w-4 h-4 text-green-300" />
              </div>
              <div>
                <p className="text-sm text-blue-100">Weekly Goal</p>
                <p className="font-semibold">{currentWeekAttendance}% / {weeklyGoal}%</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="text-right space-y-2">
          <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4 border border-white/30">
            <p className="text-sm text-blue-100 mb-1">Next Class</p>
            <p className="text-xl font-semibold mb-1">{nextClass}</p>
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-blue-200" />
              <p className="text-blue-100">{nextClassTime}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};