import React, { useState } from 'react';
import {
  Clock,
  MapPin,
  User,
  BookOpen,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Filter,
  Search,
  Bell,
  CheckCircle,
  Circle,
  AlertCircle,
  Coffee,
  Play,
  Pause,
  Eye,
  Star,
  Zap,
  Activity,
  Users
} from 'lucide-react';

const ScheduleTable = () => {
  const [selectedDay, setSelectedDay] = useState('Monday');
  const [currentWeek, setCurrentWeek] = useState(0);
  const [viewMode, setViewMode] = useState('week'); // week, day, month
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSubject, setFilterSubject] = useState('all');

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const currentTime = '10:30 AM';

  const subjects = [
    { name: 'Mathematics', color: 'from-emerald-500 to-teal-500', bgColor: 'from-emerald-500/10 to-teal-500/10', borderColor: 'border-emerald-400/20' },
    { name: 'Physics', color: 'from-blue-500 to-cyan-500', bgColor: 'from-blue-500/10 to-cyan-500/10', borderColor: 'border-blue-400/20' },
    { name: 'Chemistry', color: 'from-purple-500 to-indigo-500', bgColor: 'from-purple-500/10 to-indigo-500/10', borderColor: 'border-purple-400/20' },
    { name: 'English', color: 'from-orange-500 to-red-500', bgColor: 'from-orange-500/10 to-red-500/10', borderColor: 'border-orange-400/20' },
    { name: 'History', color: 'from-pink-500 to-rose-500', bgColor: 'from-pink-500/10 to-rose-500/10', borderColor: 'border-pink-400/20' },
    { name: 'Biology', color: 'from-green-500 to-emerald-500', bgColor: 'from-green-500/10 to-emerald-500/10', borderColor: 'border-green-400/20' }
  ];

  const scheduleData = {
    Monday: [
      {
        time: '09:00 - 10:00',
        subject: 'Mathematics',
        teacher: 'Dr. Sarah Chen',
        room: 'Room 204',
        type: 'Lecture',
        status: 'completed',
        attendance: 'present',
        description: 'Advanced Calculus - Integration Techniques',
        materials: ['Textbook Ch. 8', 'Practice Problems'],
        isLive: false
      },
      {
        time: '10:15 - 11:15',
        subject: 'Physics',
        teacher: 'Prof. Michael Roberts',
        room: 'Lab 101',
        type: 'Lab Session',
        status: 'current',
        attendance: 'present',
        description: 'Electromagnetic Induction Lab',
        materials: ['Lab Manual', 'Safety Guidelines'],
        isLive: true
      },
      {
        time: '11:30 - 12:30',
        subject: 'Chemistry',
        teacher: 'Dr. Emily Watson',
        room: 'Room 305',
        type: 'Tutorial',
        status: 'upcoming',
        attendance: null,
        description: 'Organic Chemistry - Reaction Mechanisms',
        materials: ['Reference Notes', 'Problem Sets'],
        isLive: false
      },
      {
        time: '12:30 - 01:30',
        subject: 'Lunch Break',
        teacher: null,
        room: 'Cafeteria',
        type: 'Break',
        status: 'upcoming',
        attendance: null,
        description: 'Free Period',
        materials: [],
        isLive: false
      },
      {
        time: '01:30 - 02:30',
        subject: 'English',
        teacher: 'Ms. Jennifer Adams',
        room: 'Room 108',
        type: 'Lecture',
        status: 'upcoming',
        attendance: null,
        description: 'Contemporary Literature Analysis',
        materials: ['Novel Assignment', 'Essay Guidelines'],
        isLive: false
      },
      {
        time: '02:45 - 03:45',
        subject: 'History',
        teacher: 'Prof. David Miller',
        room: 'Room 207',
        type: 'Seminar',
        status: 'upcoming',
        attendance: null,
        description: 'World War II Impact Study',
        materials: ['Documentary Links', 'Research Papers'],
        isLive: false
      }
    ],
    Tuesday: [
      {
        time: '09:00 - 10:00',
        subject: 'Biology',
        teacher: 'Dr. Lisa Park',
        room: 'Lab 203',
        type: 'Lab Session',
        status: 'upcoming',
        attendance: null,
        description: 'Cell Division and Mitosis',
        materials: ['Microscopy Guide', 'Lab Worksheets'],
        isLive: false
      },
      {
        time: '10:15 - 11:15',
        subject: 'Mathematics',
        teacher: 'Dr. Sarah Chen',
        room: 'Room 204',
        type: 'Problem Solving',
        status: 'upcoming',
        attendance: null,
        description: 'Integration Applications',
        materials: ['Problem Bank', 'Solutions Manual'],
        isLive: false
      }
    ],
    // Add similar data for other days...
  };

  const getSubjectConfig = (subjectName) => {
    return subjects.find(s => s.name === subjectName) || {
      name: subjectName,
      color: 'from-gray-500 to-slate-500',
      bgColor: 'from-gray-500/10 to-slate-500/10',
      borderColor: 'border-gray-400/20'
    };
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-emerald-400" />;
      case 'current':
        return <Play className="w-5 h-5 text-blue-400 animate-pulse" />;
      case 'upcoming':
        return <Circle className="w-5 h-5 text-white/40" />;
      default:
        return <Circle className="w-5 h-5 text-white/40" />;
    }
  };

  const getAttendanceBadge = (attendance) => {
    if (attendance === 'present') {
      return (
        <div className="flex items-center space-x-1 px-2 py-1 bg-emerald-500/20 border border-emerald-400/30 rounded-full">
          <CheckCircle className="w-3 h-3 text-emerald-400" />
          <span className="text-emerald-300 text-xs font-medium">Present</span>
        </div>
      );
    }
    if (attendance === 'absent') {
      return (
        <div className="flex items-center space-x-1 px-2 py-1 bg-red-500/20 border border-red-400/30 rounded-full">
          <AlertCircle className="w-3 h-3 text-red-400" />
          <span className="text-red-300 text-xs font-medium">Absent</span>
        </div>
      );
    }
    return null;
  };

  const currentSchedule = scheduleData[selectedDay] || [];

  const filteredSchedule = currentSchedule.filter(item => {
    const matchesSearch = item.subject?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.teacher?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterSubject === 'all' || item.subject === filterSubject;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-white via-blue-100 to-cyan-200 bg-clip-text text-transparent mb-2">
            Class Schedule
          </h1>
          <p className="text-white/70 text-lg">
            Your personalized timetable with real-time updates
          </p>
        </div>
        
        {/* Current Time Widget */}
        <div className="flex items-center space-x-4">
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl px-6 py-3 flex items-center space-x-3">
            <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
            <Clock className="w-5 h-5 text-white/70" />
            <span className="text-white font-semibold">{currentTime}</span>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        {/* Day Navigation */}
        <div className="flex items-center space-x-4">
          <button className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-200">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-2 bg-white/5 backdrop-blur-sm border border-white/20 rounded-2xl p-2">
            {days.map((day) => (
              <button
                key={day}
                onClick={() => setSelectedDay(day)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
                  selectedDay === day
                    ? 'bg-white/15 text-white shadow-lg'
                    : 'text-white/70 hover:text-white hover:bg-white/10'
                }`}
              >
                {day.slice(0, 3)}
              </button>
            ))}
          </div>
          <button className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-200">
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Search and Filters */}
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="w-5 h-5 text-white/40 absolute left-3 top-1/2 transform -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search classes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-400/50 focus:border-blue-400/50 w-64"
            />
          </div>
          <select
            value={filterSubject}
            onChange={(e) => setFilterSubject(e.target.value)}
            className="px-4 py-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white focus:outline-none focus:ring-2 focus:ring-blue-400/50 focus:border-blue-400/50"
          >
            <option value="all">All Subjects</option>
            {subjects.map((subject) => (
              <option key={subject.name} value={subject.name}>
                {subject.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 backdrop-blur-sm border border-emerald-400/20 rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-emerald-300 text-sm font-medium">Today's Classes</p>
              <p className="text-2xl font-bold text-white">6</p>
            </div>
            <Calendar className="w-8 h-8 text-emerald-400" />
          </div>
        </div>
        <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 backdrop-blur-sm border border-blue-400/20 rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-300 text-sm font-medium">Attendance Rate</p>
              <p className="text-2xl font-bold text-white">94%</p>
            </div>
            <CheckCircle className="w-8 h-8 text-blue-400" />
          </div>
        </div>
        <div className="bg-gradient-to-br from-purple-500/10 to-indigo-500/10 backdrop-blur-sm border border-purple-400/20 rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-300 text-sm font-medium">Next Class</p>
              <p className="text-lg font-bold text-white">11:30 AM</p>
            </div>
            <Clock className="w-8 h-8 text-purple-400" />
          </div>
        </div>
        <div className="bg-gradient-to-br from-orange-500/10 to-red-500/10 backdrop-blur-sm border border-orange-400/20 rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-300 text-sm font-medium">Free Periods</p>
              <p className="text-2xl font-bold text-white">2</p>
            </div>
            <Coffee className="w-8 h-8 text-orange-400" />
          </div>
        </div>
      </div>

      {/* Schedule Table */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-3xl overflow-hidden shadow-2xl">
        {/* Table Header */}
        <div className="bg-white/10 backdrop-blur-sm border-b border-white/20 p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-white flex items-center space-x-3">
              <Activity className="w-6 h-6" />
              <span>{selectedDay} Schedule</span>
            </h2>
            <div className="flex items-center space-x-2 text-white/60 text-sm">
              <Eye className="w-4 h-4" />
              <span>{filteredSchedule.length} classes</span>
            </div>
          </div>
        </div>

        {/* Schedule Cards */}
        <div className="p-6 space-y-4">
          {filteredSchedule.map((classItem, index) => {
            const subjectConfig = getSubjectConfig(classItem.subject);
            const isBreak = classItem.type === 'Break';
            
            return (
              <div
                key={index}
                className={`bg-gradient-to-r ${subjectConfig.bgColor} backdrop-blur-sm border ${subjectConfig.borderColor} rounded-2xl p-6 hover:shadow-xl transition-all duration-300 hover:scale-[1.02] ${
                  classItem.status === 'current' ? 'ring-2 ring-blue-400/50 shadow-lg shadow-blue-400/25' : ''
                }`}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-4">
                    {getStatusIcon(classItem.status)}
                    <div>
                      <div className="flex items-center space-x-3">
                        <h3 className="text-xl font-bold text-white">
                          {isBreak ? (
                            <div className="flex items-center space-x-2">
                              <Coffee className="w-5 h-5 text-orange-400" />
                              <span>Lunch Break</span>
                            </div>
                          ) : (
                            classItem.subject
                          )}
                        </h3>
                        {classItem.isLive && (
                          <div className="flex items-center space-x-2 px-3 py-1 bg-red-500/20 border border-red-400/30 rounded-full">
                            <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse"></div>
                            <span className="text-red-300 text-xs font-bold">LIVE</span>
                          </div>
                        )}
                      </div>
                      <p className="text-white/70 text-sm mt-1">{classItem.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    {getAttendanceBadge(classItem.attendance)}
                    <div className={`w-12 h-12 bg-gradient-to-r ${subjectConfig.color} rounded-2xl flex items-center justify-center shadow-lg`}>
                      {isBreak ? (
                        <Coffee className="w-6 h-6 text-white" />
                      ) : (
                        <BookOpen className="w-6 h-6 text-white" />
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                  <div className="flex items-center space-x-3">
                    <Clock className="w-5 h-5 text-white/60" />
                    <div>
                      <p className="text-white/60 text-xs font-medium">Time</p>
                      <p className="text-white font-semibold">{classItem.time}</p>
                    </div>
                  </div>
                  {!isBreak && (
                    <>
                      <div className="flex items-center space-x-3">
                        <User className="w-5 h-5 text-white/60" />
                        <div>
                          <p className="text-white/60 text-xs font-medium">Teacher</p>
                          <p className="text-white font-semibold">{classItem.teacher}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <MapPin className="w-5 h-5 text-white/60" />
                        <div>
                          <p className="text-white/60 text-xs font-medium">Location</p>
                          <p className="text-white font-semibold">{classItem.room}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Star className="w-5 h-5 text-white/60" />
                        <div>
                          <p className="text-white/60 text-xs font-medium">Type</p>
                          <p className="text-white font-semibold">{classItem.type}</p>
                        </div>
                      </div>
                    </>
                  )}
                </div>

                {!isBreak && classItem.materials && classItem.materials.length > 0 && (
                  <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4">
                    <p className="text-white/80 font-medium mb-2 flex items-center space-x-2">
                      <BookOpen className="w-4 h-4" />
                      <span>Required Materials:</span>
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {classItem.materials.map((material, idx) => (
                        <span
                          key={idx}
                          className="px-3 py-1 bg-white/10 border border-white/20 rounded-full text-white/80 text-sm"
                        >
                          {material}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {classItem.status === 'current' && (
                  <div className="mt-4 flex items-center justify-between bg-blue-500/20 border border-blue-400/30 rounded-2xl p-4">
                    <div className="flex items-center space-x-3">
                      <Zap className="w-5 h-5 text-blue-400" />
                      <span className="text-blue-300 font-medium">Class is currently in session</span>
                    </div>
                    <button className="px-4 py-2 bg-blue-500/30 hover:bg-blue-500/40 border border-blue-400/30 rounded-xl text-blue-300 font-medium transition-all duration-200 hover:scale-105">
                      Join Now
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {filteredSchedule.length === 0 && (
          <div className="p-12 text-center">
            <Calendar className="w-16 h-16 text-white/30 mx-auto mb-4" />
            <p className="text-white/60 text-lg font-medium">No classes scheduled for {selectedDay}</p>
            <p className="text-white/40 text-sm mt-2">Enjoy your free day!</p>
          </div>
        )}
      </div>

      {/* Upcoming Classes Preview */}
      <div className="bg-gradient-to-br from-emerald-500/10 to-blue-500/10 backdrop-blur-xl border border-emerald-400/20 rounded-3xl p-8 shadow-xl">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-blue-500 rounded-xl flex items-center justify-center shadow-lg">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <h3 className="text-xl font-bold text-white">Smart Recommendations</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-3">
              <BookOpen className="w-6 h-6 text-emerald-400" />
              <h4 className="font-semibold text-white">Study Suggestion</h4>
            </div>
            <p className="text-white/70 text-sm mb-2">
              Review Chapter 8 before next Mathematics class for better understanding
            </p>
            <div className="text-emerald-300 text-xs font-medium">30 min recommended</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-3">
              <Users className="w-6 h-6 text-blue-400" />
              <h4 className="font-semibold text-white">Study Group</h4>
            </div>
            <p className="text-white/70 text-sm mb-2">
              Join the Physics lab prep group meeting at 6:00 PM today
            </p>
            <div className="text-blue-300 text-xs font-medium">5 students joined</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-3">
              <Bell className="w-6 h-6 text-purple-400" />
              <h4 className="font-semibold text-white">Reminder</h4>
            </div>
            <p className="text-white/70 text-sm mb-2">
              Chemistry assignment due tomorrow at 11:59 PM
            </p>
            <div className="text-purple-300 text-xs font-medium">18 hours left</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScheduleTable;