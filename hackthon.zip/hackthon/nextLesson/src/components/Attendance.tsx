import React, { useState, useEffect, useRef } from 'react';
import {
  Camera,
  Signal,
  QrCode,
  UserCheck,
  UserX,
  Users,
  Clock,
  AlertCircle,
  CheckCircle,
  Play,
  Square,
  Download,
  Upload,
  Eye,
  EyeOff,
  Wifi,
  Bluetooth,
  Smartphone,
  MapPin,
  Activity,
  TrendingUp,
  Filter,
  Search,
  MoreHorizontal,
  RefreshCw,
  Settings,
  Calendar,
  BookOpen,
  Target,
  Zap,
  Brain
} from 'lucide-react';

const AttendanceComponent = () => {
  const [classroomSignal, setClassroomSignal] = useState(false);
  const [attendanceMethods, setAttendanceMethods] = useState({
    faceRecognition: true,
    bleProximity: false,
    qrCode: false,
    // wifiRTT: false,
    manual: false
  });
  const [currentClass, setCurrentClass] = useState(null);
  const [studentList, setStudentList] = useState([]);
  const [filteredStudents, setFilteredStudents] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [isRecording, setIsRecording] = useState(false);
  const [sessionTime, setSessionTime] = useState(0);
  const [qrCodeVisible, setQrCodeVisible] = useState(false);
  const timerRef = useRef(null);

  // Sample class data
  const classData = {
    id: 'CS601-ML-001',
    subject: 'Machine Learning',
    code: 'CS601',
    section: 'B.Tech CSE - Sem 6',
    room: 'CS-301',
    instructor: 'Dr. Priya Nair',
    startTime: '9:00 AM',
    duration: 90,
    totalStudents: 45
  };

  // Sample student data
  const initialStudents = [
    { id: 1, rollNo: 'CS2023001', name: 'Arjun Sharma', status: 'present', method: 'face-recognition', timestamp: '9:05 AM', confidence: 98, location: 'Front Row' },
    { id: 2, rollNo: 'CS2023002', name: 'Sneha Patel', status: 'present', method: 'ble-proximity', timestamp: '9:03 AM', confidence: 95, location: 'Middle Row' },
    { id: 3, rollNo: 'CS2023003', name: 'Rahul Kumar', status: 'present', method: 'face-recognition', timestamp: '9:02 AM', confidence: 97, location: 'Back Row' },
    { id: 4, rollNo: 'CS2023004', name: 'Priya Gupta', status: 'absent', method: null, timestamp: null, confidence: null, location: null },
    { id: 5, rollNo: 'CS2023005', name: 'Vikash Singh', status: 'late', method: 'qr-code', timestamp: '9:15 AM', confidence: 100, location: 'Entry' },
    { id: 6, rollNo: 'CS2023006', name: 'Anita Devi', status: 'present', method: 'face-recognition', timestamp: '9:01 AM', confidence: 96, location: 'Front Row' },
    { id: 7, rollNo: 'CS2023007', name: 'Rohan Gupta', status: 'present', method: 'ble-proximity', timestamp: '9:04 AM', confidence: 94, location: 'Middle Row' },
    { id: 8, rollNo: 'CS2023008', name: 'Deepika Sharma', status: 'absent', method: null, timestamp: null, confidence: null, location: null }
  ];

  useEffect(() => {
    setStudentList(initialStudents);
    setCurrentClass(classData);
  }, []);

  useEffect(() => {
    let filtered = studentList;
    
    if (searchTerm) {
      filtered = filtered.filter(student => 
        student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.rollNo.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (filterStatus !== 'all') {
      filtered = filtered.filter(student => student.status === filterStatus);
    }
    
    setFilteredStudents(filtered);
  }, [studentList, searchTerm, filterStatus]);

  useEffect(() => {
    if (isRecording) {
      timerRef.current = setInterval(() => {
        setSessionTime(prev => prev + 1);
      }, 1000);
    } else {
      clearInterval(timerRef.current);
    }
    
    return () => clearInterval(timerRef.current);
  }, [isRecording]);

  const toggleClassroomSignal = () => {
    setClassroomSignal(!classroomSignal);
    if (!classroomSignal) {
      setAttendanceMethods(prev => ({ ...prev, bleProximity: true }));
      setIsRecording(true);
    } else {
      setIsRecording(false);
      setSessionTime(0);
    }
  };

  const toggleAttendanceMethod = (method) => {
    setAttendanceMethods(prev => ({
      ...prev,
      [method]: !prev[method]
    }));
  };

  const markAttendance = (studentId, status, method = 'manual') => {
    setStudentList(prev => prev.map(student => 
      student.id === studentId 
        ? { 
            ...student, 
            status, 
            method: status === 'absent' ? null : method,
            timestamp: status === 'absent' ? null : new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            confidence: method === 'manual' ? 100 : student.confidence
          }
        : student
    ));
  };

  const generateQRCode = () => {
    setQrCodeVisible(true);
    setAttendanceMethods(prev => ({ ...prev, qrCode: true }));
    setTimeout(() => setQrCodeVisible(false), 30000); // Auto-hide after 30 seconds
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getAttendanceStats = () => {
    const present = studentList.filter(s => s.status === 'present').length;
    const absent = studentList.filter(s => s.status === 'absent').length;
    const late = studentList.filter(s => s.status === 'late').length;
    const total = studentList.length;
    
    return { present, absent, late, total, percentage: ((present + late) / total * 100).toFixed(1) };
  };

  const stats = getAttendanceStats();

  const methodIcons = {
    'face-recognition': Camera,
    'ble-proximity': Signal,
    'qr-code': QrCode,
    'wifi-rtt': Wifi,
    'manual': UserCheck
  };

  const methodColors = {
    'face-recognition': 'from-emerald-500 to-teal-400',
    'ble-proximity': 'from-blue-500 to-indigo-400',
    'qr-code': 'from-purple-500 to-pink-400',
    'wifi-rtt': 'from-cyan-500 to-blue-400',
    'manual': 'from-amber-500 to-orange-400'
  };

  return (
    <div className="space-y-8">
      {/* Live Session Header */}
      <div className="bg-gradient-to-r from-slate-800/50 via-blue-800/50 to-indigo-800/50 backdrop-blur-xl border border-white/20 rounded-3xl shadow-2xl overflow-hidden">
        <div className="p-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2 flex items-center">
                <BookOpen className="w-8 h-8 mr-3 text-blue-400" />
                Live Attendance Session
              </h2>
              <p className="text-white/70">
                {currentClass?.subject} - {currentClass?.section}
              </p>
            </div>
            <div className="text-right">
              <div className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-medium ${
                isRecording 
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30' 
                  : 'bg-white/10 text-white/60 border border-white/20'
              }`}>
                <div className={`w-2 h-2 rounded-full mr-2 ${
                  isRecording ? 'bg-emerald-400 animate-pulse' : 'bg-white/40'
                }`}></div>
                {isRecording ? 'RECORDING' : 'STOPPED'}
              </div>
              {isRecording && (
                <p className="text-white/60 text-sm mt-1">
                  Session Time: {formatTime(sessionTime)}
                </p>
              )}
            </div>
          </div>

          {/* Session Controls */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Control */}
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
              <h4 className="font-semibold text-white mb-4 flex items-center">
                <Activity className="w-5 h-5 mr-2" />
                Session Control
              </h4>
              <button
                onClick={toggleClassroomSignal}
                className={`w-full px-6 py-4 rounded-2xl font-semibold transition-all duration-300 transform hover:scale-105 flex items-center justify-center ${
                  classroomSignal
                    ? 'bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-400 hover:to-pink-400 text-white shadow-lg'
                    : 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white shadow-lg'
                }`}
              >
                {classroomSignal ? (
                  <>
                    <Square className="w-5 h-5 mr-2" />
                    Stop Session
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 mr-2" />
                    Start Session
                  </>
                )}
              </button>
            </div>

            {/* Live Stats */}
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
              <h4 className="font-semibold text-white mb-4 flex items-center">
                <TrendingUp className="w-5 h-5 mr-2" />
                Live Statistics
              </h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-white/70">Present:</span>
                  <span className="text-emerald-300 font-bold">{stats.present}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-white/70">Absent:</span>
                  <span className="text-red-300 font-bold">{stats.absent}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-white/70">Late:</span>
                  <span className="text-amber-300 font-bold">{stats.late}</span>
                </div>
                <div className="border-t border-white/10 pt-2">
                  <div className="flex justify-between items-center">
                    <span className="text-white/70">Attendance Rate:</span>
                    <span className="text-white font-bold">{stats.percentage}%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
              <h4 className="font-semibold text-white mb-4 flex items-center">
                <Target className="w-5 h-5 mr-2" />
                Quick Actions
              </h4>
              <div className="space-y-3">
                <button 
                  onClick={generateQRCode}
                  className="w-full px-4 py-2 bg-purple-500/20 text-purple-300 rounded-xl hover:bg-purple-500/30 transition-colors flex items-center justify-center"
                >
                  <QrCode className="w-4 h-4 mr-2" />
                  Generate QR
                </button>
                <button className="w-full px-4 py-2 bg-blue-500/20 text-blue-300 rounded-xl hover:bg-blue-500/30 transition-colors flex items-center justify-center">
                  <Download className="w-4 h-4 mr-2" />
                  Export Data
                </button>
                <button className="w-full px-4 py-2 bg-amber-500/20 text-amber-300 rounded-xl hover:bg-amber-500/30 transition-colors flex items-center justify-center">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Sync Data
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Attendance Methods */}
      <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl shadow-2xl overflow-hidden">
        <div className="p-8 border-b border-white/10">
          <h3 className="text-2xl font-bold text-white flex items-center">
            <Zap className="w-7 h-7 mr-3" />
            AI-Powered Attendance Methods
          </h3>
          <p className="text-white/70 mt-1">Multiple tracking systems for maximum accuracy</p>
        </div>
        <div className="p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {Object.entries(attendanceMethods).map(([method, isActive]) => {
              const IconComponent = methodIcons[method] || UserCheck;
              const methodName = method.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
              const gradient = methodColors[method] || 'from-gray-500 to-gray-400';
              
              return (
                <div
                  key={method}
                  className={`bg-white/5 backdrop-blur-sm border rounded-2xl p-6 transition-all duration-300 cursor-pointer hover:bg-white/10 ${
                    isActive ? 'border-white/20 shadow-lg' : 'border-white/10'
                  }`}
                  onClick={() => toggleAttendanceMethod(method)}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 bg-gradient-to-r ${gradient} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <div className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      isActive ? 'bg-emerald-400 animate-pulse shadow-lg shadow-emerald-400/50' : 'bg-white/20'
                    }`}></div>
                  </div>
                  <h4 className="font-semibold text-white mb-2">{methodName}</h4>
                  <p className={`text-sm transition-colors ${
                    isActive ? 'text-emerald-300' : 'text-white/60'
                  }`}>
                    {isActive ? 'Active' : 'Inactive'}
                  </p>
                  {method === 'faceRecognition' && isActive && (
                    <div className="mt-2 text-xs text-emerald-300 bg-emerald-500/10 px-2 py-1 rounded-lg">
                      <Brain className="w-3 h-3 inline mr-1" />
                      AI Processing
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* QR Code Modal */}
      {qrCodeVisible && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm">
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-8 max-w-md w-full mx-4 shadow-2xl">
            <div className="text-center">
              <h3 className="text-2xl font-bold text-white mb-4">QR Code Attendance</h3>
              <div className="w-64 h-64 bg-white rounded-2xl mx-auto mb-4 flex items-center justify-center">
                <div className="grid grid-cols-8 gap-1 w-48 h-48">
                  {Array.from({ length: 64 }).map((_, i) => (
                    <div
                      key={i}
                      className={`w-full h-full ${
                        Math.random() > 0.5 ? 'bg-black' : 'bg-white'
                      }`}
                    ></div>
                  ))}
                </div>
              </div>
              <p className="text-white/70 mb-4">Students can scan this QR code to mark attendance</p>
              <p className="text-emerald-300 text-sm">Auto-expires in 30 seconds</p>
              <button
                onClick={() => setQrCodeVisible(false)}
                className="mt-4 px-6 py-2 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Student List */}
      <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl shadow-2xl overflow-hidden">
        <div className="p-8 border-b border-white/10">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-2xl font-bold text-white">Student Attendance</h3>
              <p className="text-white/70 mt-1">Real-time attendance tracking</p>
            </div>
            <div className="flex items-center space-x-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/40" />
                <input
                  type="text"
                  placeholder="Search students..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/40 focus:outline-none focus:border-white/40"
                />
              </div>
              {/* Filter */}
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-4 py-2 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:border-white/40"
              >
                <option value="all" className="bg-slate-800">All Students</option>
                <option value="present" className="bg-slate-800">Present</option>
                <option value="absent" className="bg-slate-800">Absent</option>
                <option value="late" className="bg-slate-800">Late</option>
              </select>
            </div>
          </div>
        </div>

        <div className="p-8">
          <div className="space-y-4">
            {filteredStudents.map((student) => {
              const IconComponent = student.method ? methodIcons[student.method] : UserX;
              const statusColor = {
                present: 'text-emerald-300 bg-emerald-500/20',
                absent: 'text-red-300 bg-red-500/20',
                late: 'text-amber-300 bg-amber-500/20'
              };

              return (
                <div
                  key={student.id}
                  className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-300"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                        student.status === 'present' 
                          ? 'bg-gradient-to-r from-emerald-500 to-teal-400' 
                          : student.status === 'late'
                          ? 'bg-gradient-to-r from-amber-500 to-orange-400'
                          : 'bg-gradient-to-r from-red-500 to-pink-400'
                      }`}>
                        {student.status === 'present' ? (
                          <CheckCircle className="w-6 h-6 text-white" />
                        ) : student.status === 'late' ? (
                          <Clock className="w-6 h-6 text-white" />
                        ) : (
                          <UserX className="w-6 h-6 text-white" />
                        )}
                      </div>
                      <div>
                        <p className="font-semibold text-white text-lg">{student.name}</p>
                        <p className="text-white/60">{student.rollNo}</p>
                        {student.timestamp && (
                          <div className="flex items-center space-x-4 mt-1">
                            <span className="text-white/50 text-sm">
                              Marked at {student.timestamp}
                            </span>
                            {student.method && (
                              <div className="flex items-center space-x-1">
                                <IconComponent className="w-4 h-4 text-blue-300" />
                                <span className="text-blue-300 text-xs capitalize">
                                  {student.method.replace('-', ' ')}
                                </span>
                              </div>
                            )}
                            {student.confidence && (
                              <span className="text-emerald-300 text-xs">
                                {student.confidence}% accuracy
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      {student.location && (
                        <div className="flex items-center text-white/60 text-sm">
                          <MapPin className="w-4 h-4 mr-1" />
                          {student.location}
                        </div>
                      )}
                      <div className={`px-3 py-1 rounded-full text-sm font-medium ${statusColor[student.status]}`}>
                        {student.status.charAt(0).toUpperCase() + student.status.slice(1)}
                      </div>
                      <div className="flex items-center space-x-2">
                        <button 
                          onClick={() => markAttendance(student.id, 'present')}
                          className="p-2 bg-emerald-500/20 text-emerald-300 rounded-lg hover:bg-emerald-500/30 transition-colors"
                        >
                          <CheckCircle className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => markAttendance(student.id, 'absent')}
                          className="p-2 bg-red-500/20 text-red-300 rounded-lg hover:bg-red-500/30 transition-colors"
                        >
                          <UserX className="w-4 h-4" />
                        </button>
                        <button className="p-2 bg-white/10 text-white/60 rounded-lg hover:bg-white/20 transition-colors">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Attendance Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl shadow-2xl overflow-hidden">
          <div className="p-8 border-b border-white/10">
            <h4 className="text-xl font-bold text-white">Attendance Overview</h4>
          </div>
          <div className="p-8">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-white/70">Present Students</span>
                <span className="text-2xl font-bold text-emerald-300">{stats.present}</span>
              </div>
              <div className="bg-white/5 rounded-full h-4 overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-emerald-400 to-teal-400 h-4 transition-all duration-1000"
                  style={{ width: `${(stats.present / stats.total) * 100}%` }}
                ></div>
              </div>
              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="text-center">
                  <p className="text-emerald-300 text-2xl font-bold">{stats.present}</p>
                  <p className="text-white/60 text-sm">Present</p>
                </div>
                <div className="text-center">
                  <p className="text-amber-300 text-2xl font-bold">{stats.late}</p>
                  <p className="text-white/60 text-sm">Late</p>
                </div>
                <div className="text-center">
                  <p className="text-red-300 text-2xl font-bold">{stats.absent}</p>
                  <p className="text-white/60 text-sm">Absent</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl shadow-2xl overflow-hidden">
          <div className="p-8 border-b border-white/10">
            <h4 className="text-xl font-bold text-white">Method Distribution</h4>
          </div>
          <div className="p-8">
            <div className="space-y-4">
              {Object.entries(
                studentList
                  .filter(s => s.method)
                  .reduce((acc, student) => {
                    acc[student.method] = (acc[student.method] || 0) + 1;
                    return acc;
                  }, {})
              ).map(([method, count]) => {
                const IconComponent = methodIcons[method];
                const percentage = ((count / (stats.present + stats.late)) * 100).toFixed(1);
                
                return (
                  <div key={method} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 bg-gradient-to-r ${methodColors[method]} rounded-lg flex items-center justify-center`}>
                        <IconComponent className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-white capitalize">
                        {method.replace('-', ' ')}
                      </span>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-semibold">{count}</p>
                      <p className="text-white/60 text-sm">{percentage}%</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AttendanceComponent;