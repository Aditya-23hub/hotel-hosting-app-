import {
  BookOpen,
  Users,
  Star,
  UserCheck,
  Signal,
  Camera,
  QrCode,
  Activity,
  Zap,
  Brain,
} from "lucide-react";

export default function TDashboard() {
  const teacherData = {
    name: "Dr. Priya Nair",
    employeeId: "CS2019008",
    department: "Computer Science & Engineering",
    currentClass: "Machine Learning - CS601",
    nextClass: "Data Mining - CS603",
    nextClassTime: "2:30 PM",
    studentsPresent: 42,
    totalStudents: 45,
    attendanceRate: 93.3,
  };

  const todaySchedule = [
    {
      time: "9:00 AM",
      subject: "Machine Learning",
      class: "B.Tech CSE - Sem 6",
      room: "CS-301",
      students: 45,
      present: 42,
      status: "completed",
      attendanceMethod: ["face-recognition", "ble"],
    },
    {
      time: "11:00 AM",
      subject: "Data Structures",
      class: "B.Tech CSE - Sem 4",
      room: "CS-205",
      students: 38,
      present: 35,
      status: "completed",
      attendanceMethod: ["face-recognition", "qr-code"],
    },
    {
      time: "2:30 PM",
      subject: "Data Mining",
      class: "B.Tech CSE - Sem 7",
      room: "CS-Lab2",
      students: 40,
      present: null,
      status: "upcoming",
      attendanceMethod: [],
    },
    {
      time: "4:00 PM",
      subject: "AI Workshop",
      class: "B.Tech CSE - All Sems",
      room: "Auditorium",
      students: 120,
      present: null,
      status: "upcoming",
      attendanceMethod: [],
    },
  ];

  const recentFeedback = [
    {
      student: "Arjun Sharma",
      rating: 5,
      comment: "Excellent explanation of ML algorithms",
      date: "Mar 15",
    },
    {
      student: "Sneha Patel",
      rating: 4,
      comment: "Good pace, more examples would help",
      date: "Mar 14",
    },
    {
      student: "Rahul Kumar",
      rating: 5,
      comment: "Very clear and engaging lectures",
      date: "Mar 13",
    },
  ];

  const classroomStats = {
    totalClasses: 156,
    averageAttendance: 89.2,
    studentFeedback: 4.7,
    completionRate: 94.5,
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 rounded-3xl p-8 text-white shadow-2xl">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold mb-2 bg-gradient-to-r from-white via-emerald-100 to-teal-100 bg-clip-text text-transparent">
              Good morning, Dr. {teacherData.name.split(" ")[1]}!
            </h2>
            <p className="text-emerald-100 text-lg">
              Your next class starts in 30 minutes
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm text-emerald-100 mb-1">Next Class</p>
            <p className="text-xl font-semibold text-white">
              {teacherData.nextClass}
            </p>
            <p className="text-emerald-100">at {teacherData.nextClassTime}</p>
          </div>
        </div>
        <div className="mt-6 grid grid-cols-3 gap-4">
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-4 hover:bg-white/15 transition-all duration-300">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-white/90 font-semibold">AI-Powered</p>
                <p className="text-white/60 text-sm">Smart automation</p>
              </div>
            </div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-4 hover:bg-white/15 transition-all duration-300">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-white/90 font-semibold">Intelligent</p>
                <p className="text-white/60 text-sm">Smart insights</p>
              </div>
            </div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-4 hover:bg-white/15 transition-all duration-300">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-white/90 font-semibold">Real-time</p>
                <p className="text-white/60 text-sm">Live tracking</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 shadow-xl hover:bg-white/15 transition-all duration-300 group">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-white/70 mb-2">Today's Attendance</p>
              <p className="text-3xl font-bold text-emerald-300">
                {teacherData.attendanceRate}%
              </p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-400 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
              <UserCheck className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 shadow-xl hover:bg-white/15 transition-all duration-300 group">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-white/70 mb-2">Students Present</p>
              <p className="text-3xl font-bold text-blue-300">
                {teacherData.studentsPresent}/{teacherData.totalStudents}
              </p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-400 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
              <Users className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 shadow-xl hover:bg-white/15 transition-all duration-300 group">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-white/70 mb-2">Feedback Rating</p>
              <p className="text-3xl font-bold text-amber-300">
                {classroomStats.studentFeedback}
              </p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-r from-amber-500 to-orange-400 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
              <Star className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 shadow-xl hover:bg-white/15 transition-all duration-300 group">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-white/70 mb-2">Total Classes</p>
              <p className="text-3xl font-bold text-purple-300">
                {classroomStats.totalClasses}
              </p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-400 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Today's Schedule */}
      <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl shadow-2xl overflow-hidden">
        <div className="p-8 border-b border-white/10">
          <h3 className="text-2xl font-bold text-white">Today's Classes</h3>
          <p className="text-white/70 mt-1">
            Your scheduled sessions for today
          </p>
        </div>
        <div className="p-8">
          <div className="space-y-6">
            {todaySchedule.map((item, index) => (
              <div
                key={index}
                className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-300 group"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div
                      className={`w-4 h-4 rounded-full ${
                        item.status === "completed"
                          ? "bg-emerald-400 shadow-lg shadow-emerald-400/50"
                          : "bg-blue-400 shadow-lg shadow-blue-400/50 animate-pulse"
                      }`}
                    ></div>
                    <div>
                      <p className="font-semibold text-white text-lg">
                        {item.subject}
                      </p>
                      <p className="text-white/60">
                        {item.class} • {item.room}
                      </p>
                      {item.attendanceMethod.length > 0 && (
                        <div className="flex items-center space-x-3 mt-2">
                          {item.attendanceMethod.includes(
                            "face-recognition"
                          ) && (
                            <div className="flex items-center text-sm text-emerald-300 bg-emerald-500/20 px-2 py-1 rounded-lg">
                              <Camera className="w-4 h-4 mr-1" />
                              Face ID
                            </div>
                          )}
                          {item.attendanceMethod.includes("ble") && (
                            <div className="flex items-center text-sm text-blue-300 bg-blue-500/20 px-2 py-1 rounded-lg">
                              <Signal className="w-4 h-4 mr-1" />
                              BLE
                            </div>
                          )}
                          {item.attendanceMethod.includes("qr-code") && (
                            <div className="flex items-center text-sm text-purple-300 bg-purple-500/20 px-2 py-1 rounded-lg">
                              <QrCode className="w-4 h-4 mr-1" />
                              QR Code
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-white text-lg">
                      {item.time}
                    </p>
                    {item.present !== null && (
                      <div className="text-right">
                        <p className="text-white/80">
                          {item.present}/{item.students}
                        </p>
                        <p className="text-white/60 text-sm">
                          {Math.round((item.present / item.students) * 100)}%
                          present
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Student Feedback */}
      <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl shadow-2xl overflow-hidden">
        <div className="p-8 border-b border-white/10">
          <h3 className="text-2xl font-bold text-white">
            Recent Student Feedback
          </h3>
          <p className="text-white/70 mt-1">What your students are saying</p>
        </div>
        <div className="p-8">
          <div className="space-y-6">
            {recentFeedback.map((feedback, index) => (
              <div
                key={index}
                className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-4">
                  <p className="font-semibold text-white">{feedback.student}</p>
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-5 h-5 ${
                          i < feedback.rating
                            ? "text-amber-400 fill-current"
                            : "text-white/20"
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <p className="text-white/80 mb-3 italic">
                  "{feedback.comment}"
                </p>
                <p className="text-white/50 text-sm">{feedback.date}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
